export interface InvoiceItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  total: number;
}

export interface ShippingCompany {
  id: string;
  name: string;
  defaultCost: number;
  phone?: string;
  notes?: string;
  isPinned: boolean;
  isDefault?: boolean;
}

export interface SellerCompany {
  id: string;
  name: string;
  logoUrl?: string;
  phone: string;
  address: string;
  taxId?: string;
  commercialReg?: string;
  footerPolicy?: string;
  currency: string;
  isDefault: boolean;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  secondaryPhone?: string;
  address: string;
  city?: string;
  notes?: string;
  createdAt: string;
}

export type PaymentMethod = 
  | 'cash_on_delivery' 
  | 'prepaid' 
  | 'bank_transfer' 
  | 'instapay' 
  | 'vodafone_cash' 
  | 'card';

export type InvoiceStatus = 
  | 'draft' 
  | 'confirmed' 
  | 'shipped' 
  | 'delivered' 
  | 'returned' 
  | 'cancelled';

export interface InvoiceCustomization {
  template: 'modern' | 'classic' | 'minimal' | 'thermal_80mm';
  paperSize: 'a4' | 'a5' | 'thermal_80mm';
  primaryColor: string; // hex code
  fontFamily: 'Cairo' | 'Tajawal' | 'Almarai' | 'Amiri' | 'sans-serif';
  showLogo: boolean;
  logoUrl?: string;
  logoSize: 'small' | 'medium' | 'large';
  showStamp: boolean;
  showQrCode: boolean;
  showBarcode: boolean;
  showTafqeet: boolean;
  showTerms: boolean;
  showDeliveryNotes: boolean;
  headerTitle: string; // e.g. "فاتورة مبيعات" or "فاتورة ضريبية" or "إذن شحن وتسليم"
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  customerId?: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  customerCity?: string;
  items: InvoiceItem[];
  shippingCompany: string; // اسم شركة الشحن
  shippingCost: number;     // سعر الشحن بجوار اسم الشركة
  discount: number;
  taxRate: number; // e.g. 0% or 14%
  subtotal: number;
  total: number;
  paymentMethod: PaymentMethod;
  status: InvoiceStatus;
  notes?: string;
  sellerCompanyId?: string;
  createdAt: string;
  extractedFromImage?: boolean;
  customization?: Partial<InvoiceCustomization>;
}
