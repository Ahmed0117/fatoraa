import {
  Customer,
  Invoice,
  InvoiceCustomization,
  SellerCompany,
  ShippingCompany,
} from '../types';

const STORAGE_KEYS = {
  CUSTOMERS: 'smart_invoice_customers_v1',
  INVOICES: 'smart_invoice_invoices_v1',
  SHIPPING_COMPANIES: 'smart_invoice_shipping_companies_v1',
  SELLER_COMPANIES: 'smart_invoice_seller_companies_v1',
  CUSTOMIZATION: 'smart_invoice_customization_v1',
};

export const DEFAULT_CUSTOMIZATION: InvoiceCustomization = {
  template: 'modern',
  paperSize: 'a4',
  primaryColor: '#1e3a8a', // Deep royal navy
  fontFamily: 'Cairo',
  showLogo: true,
  logoSize: 'medium',
  showStamp: true,
  showQrCode: true,
  showBarcode: true,
  showTafqeet: true,
  showTerms: true,
  showDeliveryNotes: true,
  headerTitle: 'فاتورة مبيعات وتسليم',
};

// Initial Seed Data
const INITIAL_SHIPPING_COMPANIES: ShippingCompany[] = [
  {
    id: 'ship-1',
    name: 'بوسطة (Bosta)',
    defaultCost: 55,
    phone: '19035',
    notes: 'توصيل خلال 24-48 ساعة، خدمة شحن سريع',
    isPinned: true,
    isDefault: true,
  },
  {
    id: 'ship-2',
    name: 'أرامكس (Aramex)',
    defaultCost: 65,
    phone: '16996',
    notes: 'شحن جميع المحافظات والمدن مع تتبع مباشر',
    isPinned: true,
    isDefault: false,
  },
  {
    id: 'ship-3',
    name: 'سمسا إكسبريس (SMSA)',
    defaultCost: 70,
    phone: '01123456789',
    notes: 'شحن سريع وأمان عالي للبضائع القيمة',
    isPinned: true,
    isDefault: false,
  },
  {
    id: 'ship-4',
    name: 'ريد بوكس (RedBox)',
    defaultCost: 45,
    phone: '01000000010',
    notes: 'خزائن ذكية وتوصيل للمنزل',
    isPinned: true,
    isDefault: false,
  },
  {
    id: 'ship-5',
    name: 'مايلرز (Mylerz)',
    defaultCost: 50,
    phone: '19890',
    notes: 'توصيل في نفس اليوم لمدن القاهرة الكبرى',
    isPinned: false,
    isDefault: false,
  },
  {
    id: 'ship-6',
    name: 'مندوب خاص (توصيل فوري)',
    defaultCost: 40,
    phone: '01234567890',
    notes: 'تسليم يد بيد وتحصيل كاش فوري',
    isPinned: true,
    isDefault: false,
  },
];

const INITIAL_SELLER_COMPANIES: SellerCompany[] = [
  {
    id: 'seller-1',
    name: 'مؤسسة الأفق للتجارة والتوزيع',
    phone: '01012345678',
    address: 'شارع التسعين الشمالي، التجمع الخامس، القاهرة',
    taxId: '654-892-120',
    commercialReg: '108420',
    currency: 'ج.م',
    footerPolicy: 'البضاعة المباعة ترد وتستبدل خلال 14 يوماً من تاريخ الاستلام في حالتها الأصلية مع إرفاق الفاتورة.',
    isDefault: true,
    logoUrl: 'https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&auto=format&fit=crop&q=60',
  },
  {
    id: 'seller-2',
    name: 'متجر الصفوة أونلاين',
    phone: '01198765432',
    address: 'شارع المعز، وسط البلد، الإسكندرية',
    taxId: '321-456-789',
    commercialReg: '84920',
    currency: 'ج.م',
    footerPolicy: 'شكراً لتعاملكم معنا. يُرجى فحص المنتجات مع المندوب قبل الاستلام والتوقيع.',
    isDefault: false,
  },
];

const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    name: 'م. أحمد الشناوي',
    phone: '01098765432',
    secondaryPhone: '01223456789',
    address: 'عمارة 14، شارع الثورة، بجوار بنك مصر، مصر الجديدة',
    city: 'القاهرة',
    notes: 'عميل VIP دائم، يفضل التوصيل بعد الساعة 3 عصراً',
    createdAt: '2026-08-10T10:00:00Z',
  },
  {
    id: 'cust-2',
    name: 'د. سارة عبد الرحمن',
    phone: '01123456780',
    address: 'فيلا 8، حي النرجس، التجمع الخامس',
    city: 'القاهرة الجديدة',
    notes: 'الدفع دائماً كاش عند الاستلام بعد الفحص',
    createdAt: '2026-08-22T14:30:00Z',
  },
  {
    id: 'cust-3',
    name: 'أ. محمود فوزي',
    phone: '01287654321',
    address: 'شارع جمال عبد الناصر، عمارة الأطباء، سموحة',
    city: 'الإسكندرية',
    notes: 'شحن أرامكس أو بوسطة',
    createdAt: '2026-09-05T09:15:00Z',
  },
  {
    id: 'cust-4',
    name: 'أ. مروة طارق السيد',
    phone: '01511223344',
    address: 'شارع الهرم الرئيسي، محطة العريش، الجيزة',
    city: 'الجيزة',
    notes: 'الاتصال قبل التوصيل بنصف ساعة',
    createdAt: '2026-09-18T16:40:00Z',
  },
];

const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'inv-1001',
    invoiceNumber: 'INV-2026-1001',
    date: '2026-10-12',
    customerId: 'cust-1',
    customerName: 'م. أحمد الشناوي',
    customerPhone: '01098765432',
    customerAddress: 'عمارة 14، شارع الثورة، بجوار بنك مصر، مصر الجديدة',
    customerCity: 'القاهرة',
    items: [
      { id: 'item-1', name: 'ساعة ذكية فاخرة مقاومة للماء (Ultra Pro)', quantity: 1, price: 1450, total: 1450 },
      { id: 'item-2', name: 'سماعة بلوتوث لاسلكية عازلة للضوضاء', quantity: 2, price: 650, total: 1300 },
    ],
    shippingCompany: 'بوسطة (Bosta)',
    shippingCost: 55,
    discount: 50,
    taxRate: 0,
    subtotal: 2750,
    total: 2755,
    paymentMethod: 'cash_on_delivery',
    status: 'delivered',
    notes: 'تم التسليم بنجاح مع مندوب بوسطة',
    sellerCompanyId: 'seller-1',
    createdAt: '2026-10-12T11:00:00Z',
  },
  {
    id: 'inv-1002',
    invoiceNumber: 'INV-2026-1002',
    date: '2026-10-14',
    customerId: 'cust-2',
    customerName: 'د. سارة عبد الرحمن',
    customerPhone: '01123456780',
    customerAddress: 'فيلا 8، حي النرجس، التجمع الخامس',
    customerCity: 'القاهرة الجديدة',
    items: [
      { id: 'item-3', name: 'حقيبة سفر جلدية أنيقة مقاس 24 بوصة', quantity: 1, price: 1850, total: 1850 },
      { id: 'item-4', name: 'منظم إلكترونيات وأسلاك محمول', quantity: 1, price: 250, total: 250 },
    ],
    shippingCompany: 'أرامكس (Aramex)',
    shippingCost: 65,
    discount: 0,
    taxRate: 0,
    subtotal: 2100,
    total: 2165,
    paymentMethod: 'cash_on_delivery',
    status: 'shipped',
    notes: 'توصيل عاجل قبل نهاية الأسبوع',
    sellerCompanyId: 'seller-1',
    createdAt: '2026-10-14T15:20:00Z',
  },
  {
    id: 'inv-1003',
    invoiceNumber: 'INV-2026-1003',
    date: '2026-10-15',
    customerId: 'cust-3',
    customerName: 'أ. محمود فوزي',
    customerPhone: '01287654321',
    customerAddress: 'شارع جمال عبد الناصر، عمارة الأطباء، سموحة',
    customerCity: 'الإسكندرية',
    items: [
      { id: 'item-5', name: 'ماكينة حلاقة وتشذيب رجالية متعددة الشفرات', quantity: 1, price: 890, total: 890 },
    ],
    shippingCompany: 'سمسا إكسبريس (SMSA)',
    shippingCost: 70,
    discount: 40,
    taxRate: 0,
    subtotal: 890,
    total: 920,
    paymentMethod: 'cash_on_delivery',
    status: 'confirmed',
    notes: 'جاهزة للشحن مع بوليسة سمسا',
    sellerCompanyId: 'seller-1',
    createdAt: '2026-10-15T12:00:00Z',
  },
];

// Helper to safely access localStorage
function getLocalItem<T>(key: string, defaultVal: T): T {
  if (typeof window === 'undefined') return defaultVal;
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultVal;
  } catch (e) {
    console.error(`Error reading ${key} from localStorage:`, e);
    return defaultVal;
  }
}

function setLocalItem<T>(key: string, val: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (e) {
    console.error(`Error saving ${key} to localStorage:`, e);
  }
}

// Customers Storage API
export function getCustomers(): Customer[] {
  return getLocalItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
}

export function saveCustomer(customer: Customer): Customer[] {
  const current = getCustomers();
  const index = current.findIndex((c) => c.id === customer.id || (c.phone && c.phone === customer.phone));
  let updated: Customer[];
  if (index >= 0) {
    updated = current.map((c, i) => (i === index ? { ...c, ...customer } : c));
  } else {
    updated = [customer, ...current];
  }
  setLocalItem(STORAGE_KEYS.CUSTOMERS, updated);
  return updated;
}

export function deleteCustomer(id: string): Customer[] {
  const current = getCustomers();
  const updated = current.filter((c) => c.id !== id);
  setLocalItem(STORAGE_KEYS.CUSTOMERS, updated);
  return updated;
}

// Invoices Storage API
export function getInvoices(): Invoice[] {
  return getLocalItem<Invoice[]>(STORAGE_KEYS.INVOICES, INITIAL_INVOICES);
}

export function saveInvoice(invoice: Invoice): Invoice[] {
  const current = getInvoices();
  const index = current.findIndex((inv) => inv.id === invoice.id);
  let updated: Invoice[];
  if (index >= 0) {
    updated = current.map((inv) => (inv.id === invoice.id ? invoice : inv));
  } else {
    updated = [invoice, ...current];
  }
  setLocalItem(STORAGE_KEYS.INVOICES, updated);

  // Automatically update or create customer record with their latest address and phone
  if (invoice.customerName && invoice.customerPhone) {
    const existingCust = getCustomers().find(
      (c) => c.phone === invoice.customerPhone || c.id === invoice.customerId
    );
    if (existingCust) {
      saveCustomer({
        ...existingCust,
        name: invoice.customerName,
        phone: invoice.customerPhone,
        address: invoice.customerAddress || existingCust.address,
        city: invoice.customerCity || existingCust.city,
      });
    } else {
      saveCustomer({
        id: invoice.customerId || 'cust-' + Date.now(),
        name: invoice.customerName,
        phone: invoice.customerPhone,
        address: invoice.customerAddress,
        city: invoice.customerCity,
        createdAt: new Date().toISOString(),
      });
    }
  }

  return updated;
}

export function deleteInvoice(id: string): Invoice[] {
  const current = getInvoices();
  const updated = current.filter((inv) => inv.id !== id);
  setLocalItem(STORAGE_KEYS.INVOICES, updated);
  return updated;
}

// Shipping Companies Storage API
export function getShippingCompanies(): ShippingCompany[] {
  return getLocalItem<ShippingCompany[]>(
    STORAGE_KEYS.SHIPPING_COMPANIES,
    INITIAL_SHIPPING_COMPANIES
  );
}

export function saveShippingCompany(company: ShippingCompany): ShippingCompany[] {
  const current = getShippingCompanies();
  const index = current.findIndex((c) => c.id === company.id);
  let updated: ShippingCompany[];
  if (index >= 0) {
    updated = current.map((c) => (c.id === company.id ? company : c));
  } else {
    updated = [...current, company];
  }
  setLocalItem(STORAGE_KEYS.SHIPPING_COMPANIES, updated);
  return updated;
}

export function togglePinShippingCompany(id: string): ShippingCompany[] {
  const current = getShippingCompanies();
  const updated = current.map((c) => (c.id === id ? { ...c, isPinned: !c.isPinned } : c));
  setLocalItem(STORAGE_KEYS.SHIPPING_COMPANIES, updated);
  return updated;
}

export function deleteShippingCompany(id: string): ShippingCompany[] {
  const current = getShippingCompanies();
  const updated = current.filter((c) => c.id !== id);
  setLocalItem(STORAGE_KEYS.SHIPPING_COMPANIES, updated);
  return updated;
}

// Seller Companies Storage API
export function getSellerCompanies(): SellerCompany[] {
  return getLocalItem<SellerCompany[]>(
    STORAGE_KEYS.SELLER_COMPANIES,
    INITIAL_SELLER_COMPANIES
  );
}

export function saveSellerCompany(company: SellerCompany): SellerCompany[] {
  const current = getSellerCompanies();
  const index = current.findIndex((c) => c.id === company.id);
  let updated: SellerCompany[];
  if (index >= 0) {
    updated = current.map((c) => (c.id === company.id ? company : c));
  } else {
    updated = [...current, company];
  }
  setLocalItem(STORAGE_KEYS.SELLER_COMPANIES, updated);
  return updated;
}

export function getDefaultSellerCompany(): SellerCompany {
  const companies = getSellerCompanies();
  return companies.find((c) => c.isDefault) || companies[0] || INITIAL_SELLER_COMPANIES[0];
}

// Customization Storage API
export function getCustomization(): InvoiceCustomization {
  return getLocalItem<InvoiceCustomization>(
    STORAGE_KEYS.CUSTOMIZATION,
    DEFAULT_CUSTOMIZATION
  );
}

export function saveCustomization(customization: InvoiceCustomization): void {
  setLocalItem(STORAGE_KEYS.CUSTOMIZATION, customization);
}
