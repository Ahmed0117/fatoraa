/**
 * صور ونماذج فواتير وإيصالات شحن مجهزة لاختبار القراءة بالذكاء الاصطناعي
 */

export interface SampleImage {
  id: string;
  title: string;
  category: string;
  dataUrl: string;
  description: string;
}

// Generate high-resolution SVG rendered image for WhatsApp order slip
function createWhatsAppOrderSvg(): string {
  const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="700" height="900" viewBox="0 0 700 900">
  <rect width="700" height="900" fill="#EFEAE2"/>
  <rect width="700" height="70" fill="#075E54"/>
  <text x="350" y="45" font-family="'Cairo', sans-serif" font-size="22" font-weight="bold" fill="#ffffff" text-anchor="middle">طلب عميل - واتساب (متجر النور)</text>
  
  <!-- WhatsApp Chat Bubble -->
  <rect x="50" y="110" width="600" height="720" rx="16" fill="#DCF8C6" stroke="#C3E8A7" stroke-width="2"/>
  
  <text x="610" y="150" font-family="'Cairo', sans-serif" font-size="19" font-weight="bold" fill="#075E54" text-anchor="end">بيانات شحن الطلب الجديد 📦:</text>
  
  <line x1="90" y1="175" x2="610" y2="175" stroke="#C3E8A7" stroke-width="2"/>

  <text x="610" y="220" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#111827" text-anchor="end">اسم العميل:</text>
  <text x="490" y="220" font-family="'Cairo', sans-serif" font-size="18" fill="#1f2937" text-anchor="end">حسام الدين مصطفى كامل</text>

  <text x="610" y="270" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#111827" text-anchor="end">رقم الهاتف:</text>
  <text x="490" y="270" font-family="'Cairo', sans-serif" font-size="18" fill="#1f2937" text-anchor="end" direction="ltr">01023456781</text>

  <text x="610" y="320" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#111827" text-anchor="end">المحافظة / المدينة:</text>
  <text x="440" y="320" font-family="'Cairo', sans-serif" font-size="18" fill="#1f2937" text-anchor="end">الجيزة - الشيخ زايد</text>

  <text x="610" y="370" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#111827" text-anchor="end">العنوان بالتفصيل:</text>
  <text x="610" y="405" font-family="'Cairo', sans-serif" font-size="17" fill="#374151" text-anchor="end">كمبوند الياسمين، عمارة 12، الدور الثالث، شقة 6، مدخل 2</text>

  <line x1="90" y1="440" x2="610" y2="440" stroke="#C3E8A7" stroke-width="2"/>

  <text x="610" y="480" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#075E54" text-anchor="end">المنتجات المطلوبة:</text>

  <text x="610" y="525" font-family="'Cairo', sans-serif" font-size="17" fill="#111827" text-anchor="end">1. طقم أواني جرانيت تركي 10 قطع - الكمية: 1 - السعر: 2600 ج.م</text>
  <text x="610" y="570" font-family="'Cairo', sans-serif" font-size="17" fill="#111827" text-anchor="end">2. طقم سكاكين مطبخ ستانلس ستيل - الكمية: 2 - السعر: 350 ج.م (الإجمالي: 700)</text>
  <text x="610" y="615" font-family="'Cairo', sans-serif" font-size="17" fill="#111827" text-anchor="end">3. مفرمة لحوم وخضار كهربائية 300 وات - الكمية: 1 - السعر: 850 ج.م</text>

  <line x1="90" y1="655" x2="610" y2="655" stroke="#C3E8A7" stroke-width="2"/>

  <text x="610" y="700" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#1e3a8a" text-anchor="end">شركة الشحن المطلوبة: بوسطة (Bosta)</text>
  <text x="610" y="740" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#1e3a8a" text-anchor="end">تكلفة مصاريف الشحن: 55 ج.م</text>

  <text x="610" y="785" font-family="'Cairo', sans-serif" font-size="16" fill="#4b5563" text-anchor="end">ملاحظة: العميل متواجد في المنزل بعد الساعة 4 عصراً، يرجى الاتصال مسبقاً</text>
</svg>
  `.trim();

  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

// Generate shipping waybill slip
function createShippingWaybillSvg(): string {
  const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="700" height="900" viewBox="0 0 700 900">
  <rect width="700" height="900" fill="#FFFFFF"/>
  <rect x="25" y="25" width="650" height="850" rx="12" fill="#FFFFFF" stroke="#0f172a" stroke-width="3"/>

  <!-- Header -->
  <rect x="25" y="25" width="650" height="90" fill="#0f172a"/>
  <text x="50" y="75" font-family="'Cairo', sans-serif" font-size="26" font-weight="bold" fill="#FFFFFF">ARAMEX / أرامكس</text>
  <text x="640" y="75" font-family="'Cairo', sans-serif" font-size="22" font-weight="bold" fill="#38bdf8" text-anchor="end">بوليصة شحن مبيعات COD</text>

  <!-- Barcode simulation -->
  <g transform="translate(180, 140)">
    <rect x="0" y="0" width="8" height="50" fill="#000"/>
    <rect x="14" y="0" width="4" height="50" fill="#000"/>
    <rect x="24" y="0" width="12" height="50" fill="#000"/>
    <rect x="42" y="0" width="6" height="50" fill="#000"/>
    <rect x="54" y="0" width="14" height="50" fill="#000"/>
    <rect x="74" y="0" width="6" height="50" fill="#000"/>
    <rect x="86" y="0" width="10" height="50" fill="#000"/>
    <rect x="102" y="0" width="4" height="50" fill="#000"/>
    <rect x="112" y="0" width="16" height="50" fill="#000"/>
    <rect x="134" y="0" width="8" height="50" fill="#000"/>
    <rect x="148" y="0" width="12" height="50" fill="#000"/>
    <rect x="166" y="0" width="6" height="50" fill="#000"/>
    <rect x="178" y="0" width="14" height="50" fill="#000"/>
    <rect x="198" y="0" width="8" height="50" fill="#000"/>
    <rect x="212" y="0" width="4" height="50" fill="#000"/>
    <rect x="222" y="0" width="12" height="50" fill="#000"/>
    <rect x="240" y="0" width="8" height="50" fill="#000"/>
    <rect x="254" y="0" width="16" height="50" fill="#000"/>
    <rect x="276" y="0" width="6" height="50" fill="#000"/>
    <rect x="288" y="0" width="10" height="50" fill="#000"/>
    <rect x="304" y="0" width="4" height="50" fill="#000"/>
    <text x="160" y="75" font-family="monospace" font-size="16" text-anchor="middle">AMX-893049182-EG</text>
  </g>

  <!-- Consignee Details -->
  <rect x="45" y="240" width="610" height="230" fill="#f8fafc" stroke="#cbd5e1" stroke-width="1.5" rx="8"/>
  <rect x="45" y="240" width="610" height="38" fill="#e2e8f0" rx="8 8 0 0"/>
  <text x="635" y="266" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#0f172a" text-anchor="end">بيانات المرسل إليه (العميل المستلم)</text>

  <text x="630" y="315" font-family="'Cairo', sans-serif" font-size="17" font-weight="bold" fill="#334155" text-anchor="end">اسم المستلم:</text>
  <text x="500" y="315" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#0284c7" text-anchor="end">نورهان عادل الشافعي</text>

  <text x="630" y="360" font-family="'Cairo', sans-serif" font-size="17" font-weight="bold" fill="#334155" text-anchor="end">رقم الهاتف:</text>
  <text x="500" y="360" font-family="'Cairo', sans-serif" font-size="18" fill="#0f172a" text-anchor="end" direction="ltr">01155443322</text>

  <text x="630" y="405" font-family="'Cairo', sans-serif" font-size="17" font-weight="bold" fill="#334155" text-anchor="end">العنوان والمحافظة:</text>
  <text x="630" y="440" font-family="'Cairo', sans-serif" font-size="17" fill="#0f172a" text-anchor="end">الإسكندرية، محطة الرمل، شارع صفية زغلول، برج الفيروز، الدور 5</text>

  <!-- Items list -->
  <rect x="45" y="490" width="610" height="230" fill="#ffffff" stroke="#cbd5e1" stroke-width="1.5" rx="8"/>
  <rect x="45" y="490" width="610" height="36" fill="#f1f5f9" rx="8 8 0 0"/>
  <text x="630" y="515" font-family="'Cairo', sans-serif" font-size="16" font-weight="bold" fill="#334155" text-anchor="end">المنتجات المشحونة</text>
  <text x="320" y="515" font-family="'Cairo', sans-serif" font-size="16" font-weight="bold" fill="#334155" text-anchor="middle">الكمية</text>
  <text x="120" y="515" font-family="'Cairo', sans-serif" font-size="16" font-weight="bold" fill="#334155" text-anchor="middle">السعر</text>

  <text x="630" y="560" font-family="'Cairo', sans-serif" font-size="16" fill="#0f172a" text-anchor="end">فستان سهرة كريب حرير كحلي مقاس L</text>
  <text x="320" y="560" font-family="'Cairo', sans-serif" font-size="16" fill="#0f172a" text-anchor="middle">1</text>
  <text x="120" y="560" font-family="'Cairo', sans-serif" font-size="16" fill="#0f172a" text-anchor="middle">1200 ج.م</text>

  <line x1="45" y1="585" x2="655" y2="585" stroke="#e2e8f0"/>

  <text x="630" y="625" font-family="'Cairo', sans-serif" font-size="16" fill="#0f172a" text-anchor="end">شال كشمير صوف طبيعي فاخر</text>
  <text x="320" y="625" font-family="'Cairo', sans-serif" font-size="16" fill="#0f172a" text-anchor="middle">2</text>
  <text x="120" y="625" font-family="'Cairo', sans-serif" font-size="16" fill="#0f172a" text-anchor="middle">450 ج.م</text>

  <!-- Shipping and Total box -->
  <rect x="45" y="735" width="610" height="115" fill="#f0fdf4" stroke="#86efac" stroke-width="2" rx="8"/>
  <text x="630" y="775" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#166534" text-anchor="end">شركة الشحن: أرامكس (Aramex)</text>
  <text x="250" y="775" font-family="'Cairo', sans-serif" font-size="18" font-weight="bold" fill="#166534" text-anchor="end">سعر الشحن: 65 ج.م</text>
  
  <text x="630" y="820" font-family="'Cairo', sans-serif" font-size="20" font-weight="bold" fill="#0f172a" text-anchor="end">الإجمالي المطلوب تحصيله (COD): 2165 ج.م</text>
</svg>
  `.trim();

  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

export const SAMPLE_IMAGES: SampleImage[] = [
  {
    id: 'sample-whatsapp',
    title: 'طلب واتساب (أدوات منزلية)',
    category: 'محادثة طلب',
    description: 'صورة لمحادثة واتساب تحتوي على اسم العميل وعنوانه بالشيخ زايد والمنتجات وتكلفة شحن بوسطة.',
    dataUrl: createWhatsAppOrderSvg(),
  },
  {
    id: 'sample-waybill',
    title: 'بوليصة شحن أرامكس',
    category: 'إيصال شحن',
    description: 'بوليصة شحن تحتوي على اسم عميلة بالإسكندرية ومنتجات ملابس وسعر شحن أرامكس 65 ج.م.',
    dataUrl: createShippingWaybillSvg(),
  },
];
