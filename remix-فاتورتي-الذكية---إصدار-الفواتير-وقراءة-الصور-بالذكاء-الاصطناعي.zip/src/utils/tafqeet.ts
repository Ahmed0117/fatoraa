/**
 * تفقيط الأرقام وتحويلها إلى كلمات باللغة العربية للفواتير
 */

const ones = [
  '',
  'واحد',
  'اثنان',
  'ثلاثة',
  'أربعة',
  'خمسة',
  'ستة',
  'سبعة',
  'ثمانية',
  'تسعة',
  'عشرة',
  'أحد عشر',
  'اثنا عشر',
  'ثلاثة عشر',
  'أربعة عشر',
  'خمسة عشر',
  'ستة عشر',
  'سبعة عشر',
  'ثمانية عشر',
  'تسعة عشر',
];

const tens = [
  '',
  '',
  'عشرون',
  'ثلاثون',
  'أربعون',
  'خمسون',
  'ستون',
  'سبعون',
  'ثمانون',
  'تسعون',
];

const hundreds = [
  '',
  'مائة',
  'مائتان',
  'ثلاثمائة',
  'أربعمائة',
  'خمسمائة',
  'ستمائة',
  'سبعمائة',
  'ثمانمائة',
  'تسعمائة',
];

function convertGroup(n: number): string {
  let output = '';
  const h = Math.floor(n / 100);
  const rem = n % 100;

  if (h > 0) {
    output += hundreds[h];
  }

  if (rem > 0) {
    if (output !== '') {
      output += ' و';
    }
    if (rem < 20) {
      output += ones[rem];
    } else {
      const t = Math.floor(rem / 10);
      const o = rem % 10;
      if (o > 0) {
        output += ones[o] + ' و' + tens[t];
      } else {
        output += tens[t];
      }
    }
  }

  return output;
}

export function numberToArabicWords(num: number, currency: string = 'جنيه مصري'): string {
  if (num === 0) return `صفر ${currency}`;
  if (isNaN(num)) return '';

  const isNegative = num < 0;
  const absNum = Math.abs(num);

  const integerPart = Math.floor(absNum);
  const decimalPart = Math.round((absNum - integerPart) * 100);

  let result = '';

  const billions = Math.floor(integerPart / 1000000000);
  const millions = Math.floor((integerPart % 1000000000) / 1000000);
  const thousands = Math.floor((integerPart % 1000000) / 1000);
  const remaining = integerPart % 1000;

  const parts: string[] = [];

  if (billions > 0) {
    if (billions === 1) parts.push('مليار');
    else if (billions === 2) parts.push('ملياران');
    else if (billions >= 3 && billions <= 10) parts.push(convertGroup(billions) + ' مليارات');
    else parts.push(convertGroup(billions) + ' مليار');
  }

  if (millions > 0) {
    if (millions === 1) parts.push('مليون');
    else if (millions === 2) parts.push('مليونان');
    else if (millions >= 3 && millions <= 10) parts.push(convertGroup(millions) + ' ملايين');
    else parts.push(convertGroup(millions) + ' مليون');
  }

  if (thousands > 0) {
    if (thousands === 1) parts.push('ألف');
    else if (thousands === 2) parts.push('ألفان');
    else if (thousands >= 3 && thousands <= 10) parts.push(convertGroup(thousands) + ' آلاف');
    else parts.push(convertGroup(thousands) + ' ألف');
  }

  if (remaining > 0 || parts.length === 0) {
    parts.push(convertGroup(remaining));
  }

  result = parts.join(' و');

  let currencyText = currency;
  if (currency === 'ج.م' || currency === 'جنيه') {
    currencyText = 'جنيهاً مصرياً';
  } else if (currency === 'ر.س' || currency === 'ريال') {
    currencyText = 'ريالاً سعودياً';
  } else if (currency === 'د.إ' || currency === 'درهم') {
    currencyText = 'درهماً إماراتياً';
  } else if (currency === '$') {
    currencyText = 'دولار';
  }

  let finalPhrase = `فقط ${result} ${currencyText}`;

  if (decimalPart > 0) {
    finalPhrase += ` و${convertGroup(decimalPart)} قرشاً`;
  }

  finalPhrase += ' لا غير';

  if (isNegative) {
    finalPhrase = 'سالب ' + finalPhrase;
  }

  return finalPhrase;
}
