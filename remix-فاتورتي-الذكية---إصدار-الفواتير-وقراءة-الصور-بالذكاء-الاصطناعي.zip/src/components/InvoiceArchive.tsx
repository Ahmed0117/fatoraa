import React, { useState } from 'react';
import {
  Archive,
  Search,
  Printer,
  Edit2,
  Trash2,
  Copy,
  Calendar,
  Truck,
  User,
  Phone,
  DollarSign,
  Download,
  Filter,
  CheckCircle,
  Clock,
  RotateCcw,
} from 'lucide-react';
import { Invoice, InvoiceStatus } from '../types';

interface InvoiceArchiveProps {
  invoices: Invoice[];
  onSelectInvoice: (invoice: Invoice, action: 'print' | 'edit') => void;
  onDuplicateInvoice: (invoice: Invoice) => void;
  onDeleteInvoice: (id: string) => void;
  onStatusChange: (id: string, newStatus: InvoiceStatus) => void;
}

export const InvoiceArchive: React.FC<InvoiceArchiveProps> = ({
  invoices,
  onSelectInvoice,
  onDuplicateInvoice,
  onDeleteInvoice,
  onStatusChange,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('');

  const statusMap: Record<InvoiceStatus, { label: string; bg: string; text: string }> = {
    draft: { label: 'مسودة', bg: 'bg-slate-100', text: 'text-slate-700' },
    confirmed: { label: 'مؤكدة', bg: 'bg-blue-100', text: 'text-blue-800' },
    shipped: { label: 'جاري الشحن', bg: 'bg-indigo-100', text: 'text-indigo-800' },
    delivered: { label: 'تم التسليم', bg: 'bg-emerald-100', text: 'text-emerald-800' },
    returned: { label: 'مرتجع', bg: 'bg-amber-100', text: 'text-amber-800' },
    cancelled: { label: 'ملغاة', bg: 'bg-red-100', text: 'text-red-800' },
  };

  const filteredInvoices = invoices.filter((inv) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      inv.invoiceNumber.toLowerCase().includes(q) ||
      inv.customerName.toLowerCase().includes(q) ||
      inv.customerPhone.includes(q) ||
      inv.shippingCompany.toLowerCase().includes(q);

    const matchesStatus = statusFilter === 'all' || inv.status === statusFilter;
    const matchesDate = !dateFilter || inv.date === dateFilter;

    return matchesSearch && matchesStatus && matchesDate;
  });

  const totalSales = invoices.reduce((sum, inv) => sum + (Number(inv.total) || 0), 0);
  const totalShipping = invoices.reduce((sum, inv) => sum + (Number(inv.shippingCost) || 0), 0);
  const deliveredCount = invoices.filter((inv) => inv.status === 'delivered').length;

  const handleExportBackup = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(invoices, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `smart_invoices_backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-900 rounded-2xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black">أرشيف وسجل فواتير المبيعات</h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            البحث في الفواتير السابقة، إعادة الطباعة، تتبع حالات الشحن والتسليم
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportBackup}
          className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 border border-white/20 transition-all shrink-0"
        >
          <Download className="w-4 h-4" />
          تصدير نسخة احتياطية (JSON)
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold block mb-1">إجمالي المبيعات المؤرشفة</span>
          <span className="text-2xl font-black text-slate-900">
            {totalSales.toLocaleString()} <span className="text-xs text-slate-500 font-normal">ج.م</span>
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold block mb-1">إجمالي مصاريف الشحن المحصلة</span>
          <span className="text-2xl font-black text-blue-700">
            {totalShipping.toLocaleString()} <span className="text-xs text-slate-500 font-normal">ج.م</span>
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-bold block mb-1">الفواتير المسلمة بنجاح</span>
          <span className="text-2xl font-black text-emerald-600">
            {deliveredCount} <span className="text-xs text-slate-500 font-normal">من {invoices.length}</span>
          </span>
        </div>
      </div>

      {/* Filters Toolbar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:max-w-xs">
          <input
            type="text"
            placeholder="بحث بالرقم، العميل، الهاتف، الشحن..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3.5 py-2 pr-9 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5 pointer-events-none" />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 bg-white outline-none focus:ring-1 focus:ring-blue-500"
          >
            <option value="all">كل الحالات ({invoices.length})</option>
            <option value="draft">مسودة</option>
            <option value="confirmed">مؤكدة</option>
            <option value="shipped">جاري الشحن</option>
            <option value="delivered">تم التسليم</option>
            <option value="returned">مرتجع</option>
            <option value="cancelled">ملغاة</option>
          </select>

          {/* Date Filter */}
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 bg-white outline-none"
          />

          {(searchQuery || statusFilter !== 'all' || dateFilter) && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setStatusFilter('all');
                setDateFilter('');
              }}
              className="text-xs text-red-600 font-bold hover:underline px-2"
            >
              مسح الفلتر
            </button>
          )}
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 text-slate-700 text-xs font-bold border-b border-slate-200">
                <th className="py-3 px-4">رقم الفاتورة</th>
                <th className="py-3 px-4">التاريخ</th>
                <th className="py-3 px-4">العميل المستلم</th>
                <th className="py-3 px-4">شركة الشحن والسعر</th>
                <th className="py-3 px-4 text-center">الحالة</th>
                <th className="py-3 px-4 text-center">الإجمالي</th>
                <th className="py-3 px-4 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInvoices.length > 0 ? (
                filteredInvoices.map((inv) => {
                  const statusInfo = statusMap[inv.status] || statusMap.draft;
                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-mono font-black text-slate-900 text-xs">
                        {inv.invoiceNumber}
                      </td>

                      <td className="py-3 px-4 text-xs text-slate-600">
                        {inv.date}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 text-xs">
                          {inv.customerName}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono" dir="ltr">
                          {inv.customerPhone}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-xs">
                        <div className="font-bold text-blue-900 flex items-center gap-1">
                          <Truck className="w-3.5 h-3.5 text-blue-600" />
                          <span>{inv.shippingCompany || 'شحن خاص'}</span>
                        </div>
                        <div className="text-[11px] text-slate-500 font-bold">
                          مصاريف الشحن: {inv.shippingCost} ج.م
                        </div>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <select
                          value={inv.status}
                          onChange={(e) => onStatusChange(inv.id, e.target.value as InvoiceStatus)}
                          className={`text-xs font-bold px-2 py-1 rounded-full border-none outline-none cursor-pointer ${statusInfo.bg} ${statusInfo.text}`}
                        >
                          <option value="draft">مسودة</option>
                          <option value="confirmed">مؤكدة</option>
                          <option value="shipped">جاري الشحن</option>
                          <option value="delivered">تم التسليم</option>
                          <option value="returned">مرتجع</option>
                          <option value="cancelled">ملغاة</option>
                        </select>
                      </td>

                      <td className="py-3 px-4 text-center font-black text-slate-900">
                        {inv.total.toLocaleString()} <span className="text-[11px] font-normal text-slate-500">ج.م</span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={() => onSelectInvoice(inv, 'print')}
                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="طباعة الفاتورة"
                          >
                            <Printer className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            onClick={() => onSelectInvoice(inv, 'edit')}
                            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                            title="تعديل الفاتورة"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            onClick={() => onDuplicateInvoice(inv)}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="تكرار الفاتورة"
                          >
                            <Copy className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`هل أنت متأكد من حذف الفاتورة "${inv.invoiceNumber}"؟`)) {
                                onDeleteInvoice(inv.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="حذف الفاتورة"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    لا توجد فواتير مطابقة
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
