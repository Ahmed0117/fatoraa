import React from 'react';
import {
  Phone,
  MapPin,
  Truck,
  Calendar,
  FileText,
  Building,
  CheckCircle,
} from 'lucide-react';
import {
  Invoice,
  InvoiceCustomization,
  SellerCompany,
} from '../types';
import { numberToArabicWords } from '../utils/tafqeet';

interface PrintableInvoiceProps {
  invoice: Invoice;
  sellerCompany: SellerCompany;
  customization: InvoiceCustomization;
}

export const PrintableInvoice: React.FC<PrintableInvoiceProps> = ({
  invoice,
  sellerCompany,
  customization,
}) => {
  const isThermal = customization.paperSize === 'thermal_80mm';
  const isA5 = customization.paperSize === 'a5';

  const logoSizeClasses = {
    small: 'max-h-10 max-w-[120px]',
    medium: 'max-h-16 max-w-[170px]',
    large: 'max-h-24 max-w-[220px]',
  }[customization.logoSize || 'medium'];

  const fontStyle = {
    fontFamily: customization.fontFamily || 'Cairo',
  };

  const primaryColor = customization.primaryColor || '#1e3a8a';

  // Payment method Arabic labels
  const paymentLabels: Record<string, string> = {
    cash_on_delivery: '💵 نقدًا عند الاستلام (COD)',
    vodafone_cash: '📱 محفظة إلكترونية (فودافون كاش)',
    instapay: '⚡ إنستاباي (InstaPay)',
    bank_transfer: '🏦 تحويل بنكي مسبق',
    card: '💳 بطاقة بنكية',
    prepaid: '✅ مدفوع مسبقاً',
  };

  // -------------------------------------------------------------
  // THERMAL 80mm POS RECEIPT LAYOUT
  // -------------------------------------------------------------
  if (isThermal) {
    return (
      <div
        id="printable-invoice"
        style={fontStyle}
        className="w-[80mm] max-w-[80mm] mx-auto bg-white p-3 text-slate-950 text-[11px] leading-tight border border-slate-300 shadow-sm print:border-none print:shadow-none print:p-0 print:m-0"
      >
        {/* Thermal Header */}
        <div className="text-center pb-2 border-b-2 border-dashed border-slate-400">
          {customization.showLogo && (customization.logoUrl || sellerCompany.logoUrl) && (
            <img
              src={customization.logoUrl || sellerCompany.logoUrl}
              alt={sellerCompany.name}
              className="max-h-10 max-w-[100px] mx-auto mb-1 object-contain"
            />
          )}
          <h2 className="font-black text-sm text-slate-900">{sellerCompany.name}</h2>
          <p className="text-[10px] text-slate-600 mt-0.5">{sellerCompany.phone}</p>
          <div className="mt-1 pt-1 border-t border-dotted border-slate-300">
            <span className="font-black text-xs block">
              {customization.headerTitle || 'إيصال استلام وشحن'}
            </span>
            <span className="text-[10px] font-mono">رقم: {invoice.invoiceNumber}</span>
            <span className="block text-[10px]">التاريخ: {invoice.date}</span>
          </div>
        </div>

        {/* Customer Box */}
        <div className="py-2 border-b border-dashed border-slate-400 space-y-1">
          <div className="flex justify-between items-start">
            <span className="font-bold">العميل:</span>
            <span className="font-black text-right text-xs">{invoice.customerName}</span>
          </div>
          <div className="flex justify-between">
            <span className="font-bold">الهاتف:</span>
            <span className="font-black" dir="ltr">{invoice.customerPhone}</span>
          </div>
          <div className="text-[10px] mt-0.5">
            <span className="font-bold">العنوان: </span>
            <span>{invoice.customerAddress} {invoice.customerCity ? `(${invoice.customerCity})` : ''}</span>
          </div>
        </div>

        {/* Items Table */}
        <div className="py-2 border-b border-dashed border-slate-400">
          <table className="w-full text-right text-[10px]">
            <thead>
              <tr className="border-b border-slate-300 font-bold">
                <th className="pb-1">الصنف</th>
                <th className="pb-1 text-center w-8">الكمية</th>
                <th className="pb-1 text-left w-14">الإجمالي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dotted divide-slate-200">
              {invoice.items.map((item, idx) => (
                <tr key={idx}>
                  <td className="py-1 font-medium">{item.name}</td>
                  <td className="py-1 text-center font-bold">{item.quantity}</td>
                  <td className="py-1 text-left font-black">
                    {(item.quantity * item.price).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Financial Summary with Shipping Company & Fee */}
        <div className="py-2 border-b-2 border-dashed border-slate-400 space-y-1 text-xs">
          <div className="flex justify-between">
            <span>إجمالي المنتجات:</span>
            <span className="font-bold">{invoice.subtotal.toLocaleString()} ج.م</span>
          </div>

          {/* Shipping with Company Name (Required) */}
          <div className="flex justify-between font-bold bg-slate-100 p-1 rounded">
            <span>الشحن ({invoice.shippingCompany || 'شحن سريع'}):</span>
            <span className="font-black">+{invoice.shippingCost.toLocaleString()} ج.م</span>
          </div>

          {invoice.discount > 0 && (
            <div className="flex justify-between text-red-600">
              <span>الخصم:</span>
              <span>-{invoice.discount} ج.م</span>
            </div>
          )}

          <div className="flex justify-between font-black text-sm pt-1 border-t border-slate-400">
            <span>المبلغ الإجمالي المطلوب:</span>
            <span>{invoice.total.toLocaleString()} ج.م</span>
          </div>

          <div className="text-[10px] text-slate-600 text-center pt-1">
            {paymentLabels[invoice.paymentMethod] || invoice.paymentMethod}
          </div>
        </div>

        {/* Thermal Barcode / Footer */}
        {customization.showBarcode && (
          <div className="py-2 text-center">
            {/* Barcode visual lines */}
            <div className="flex justify-center items-center gap-[2px] h-9 mx-auto w-48">
              {[6, 2, 8, 4, 10, 3, 7, 2, 9, 3, 5, 2, 8, 4, 9, 3, 6, 2, 7, 4, 8, 2, 9, 3, 5, 2].map(
                (w, i) => (
                  <div key={i} className="bg-black h-full" style={{ width: `${w * 0.7}px` }} />
                )
              )}
            </div>
            <span className="font-mono text-[9px] block mt-0.5 tracking-wider">
              {invoice.invoiceNumber}
            </span>
          </div>
        )}

        {customization.showTerms && sellerCompany.footerPolicy && (
          <p className="text-[9px] text-center text-slate-500 pt-1 border-t border-dotted border-slate-300">
            {sellerCompany.footerPolicy}
          </p>
        )}
      </div>
    );
  }

  // -------------------------------------------------------------
  // STANDARD A4 & A5 INVOICE LAYOUT
  // -------------------------------------------------------------
  return (
    <div
      id="printable-invoice"
      style={fontStyle}
      className={`bg-white mx-auto print:border-none print:shadow-none print:p-0 transition-all ${
        isA5
          ? 'max-w-[210mm] p-6 text-xs'
          : 'max-w-[210mm] p-8 sm:p-10 text-sm shadow-xl border border-slate-200 rounded-2xl'
      }`}
    >
      {/* Top Header Bar with Accent Color */}
      <div
        className="h-2 rounded-t-xl mb-6 -mx-8 sm:-mx-10 -mt-8 sm:-mt-10 print:h-2"
        style={{ backgroundColor: primaryColor }}
      />

      {/* Main Header: Company info & Invoice Meta */}
      <div className="flex flex-col sm:flex-row justify-between items-start gap-6 pb-6 border-b-2 border-slate-200">
        {/* Seller Info & Logo */}
        <div className="flex items-start gap-4">
          {customization.showLogo && (customization.logoUrl || sellerCompany.logoUrl) && (
            <div className="bg-white p-1 rounded-xl border border-slate-200 shrink-0 shadow-xs">
              <img
                src={customization.logoUrl || sellerCompany.logoUrl}
                alt={sellerCompany.name}
                className={`${logoSizeClasses} object-contain`}
              />
            </div>
          )}

          <div>
            <h1
              className="text-xl sm:text-2xl font-black tracking-tight"
              style={{ color: primaryColor }}
            >
              {sellerCompany.name}
            </h1>
            <p className="text-xs text-slate-600 mt-1 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>{sellerCompany.address}</span>
            </p>
            <p className="text-xs text-slate-600 flex items-center gap-1.5 mt-0.5">
              <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span dir="ltr">{sellerCompany.phone}</span>
            </p>

            {(sellerCompany.taxId || sellerCompany.commercialReg) && (
              <div className="flex flex-wrap gap-2 text-[11px] text-slate-500 mt-1.5">
                {sellerCompany.taxId && (
                  <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                    رقم ضريبي: {sellerCompany.taxId}
                  </span>
                )}
                {sellerCompany.commercialReg && (
                  <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                    س.ت: {sellerCompany.commercialReg}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Invoice Title & Meta */}
        <div className="text-left sm:text-left self-stretch sm:self-auto flex flex-col justify-between">
          <div>
            <span
              className="inline-block px-3 py-1 text-white text-xs sm:text-sm font-bold rounded-lg mb-2 shadow-xs"
              style={{ backgroundColor: primaryColor }}
            >
              {customization.headerTitle || 'فاتورة مبيعات وتسليم'}
            </span>
            <div className="text-sm font-mono font-black text-slate-800">
              #{invoice.invoiceNumber}
            </div>
          </div>

          <div className="text-xs text-slate-600 mt-3 space-y-1">
            <div className="flex items-center justify-between sm:justify-start gap-3">
              <span className="font-bold text-slate-700">تاريخ الإصدار:</span>
              <span>{invoice.date}</span>
            </div>
            <div className="flex items-center justify-between sm:justify-start gap-3">
              <span className="font-bold text-slate-700">طريقة التحصيل:</span>
              <span className="font-semibold text-slate-900">
                {paymentLabels[invoice.paymentMethod] || invoice.paymentMethod}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Customer & Shipping Details Boxes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6">
        {/* Customer Details Box */}
        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70">
          <div className="text-xs font-black text-slate-500 mb-2 uppercase tracking-wider flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-blue-600" />
            بيانات المستلم / العميل:
          </div>

          <div className="space-y-1.5">
            <div className="text-base font-black text-slate-900">
              {invoice.customerName || 'عميل غير مسجل'}
            </div>
            <div className="text-xs font-bold text-slate-800 flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              <span dir="ltr">{invoice.customerPhone || 'بدون هاتف'}</span>
            </div>
            <div className="text-xs text-slate-700 flex items-start gap-2 pt-0.5">
              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
              <span>
                {invoice.customerAddress || 'بدون عنوان'}
                {invoice.customerCity ? `، ${invoice.customerCity}` : ''}
              </span>
            </div>

            {customization.showDeliveryNotes && invoice.notes && (
              <div className="mt-2 pt-2 border-t border-slate-200 text-xs text-amber-900 bg-amber-50 p-2 rounded-lg font-medium">
                <span className="font-bold">ملاحظات التوصيل: </span>
                {invoice.notes}
              </div>
            )}
          </div>
        </div>

        {/* Shipping Company & Waybill Details Box (Directly displays company + cost) */}
        <div
          className="p-4 rounded-xl border border-blue-200 bg-blue-50/50 flex flex-col justify-between"
          style={{ borderColor: `${primaryColor}40` }}
        >
          <div>
            <div className="text-xs font-black text-blue-900 mb-2 uppercase tracking-wider flex items-center gap-1.5">
              <Truck className="w-4 h-4 text-blue-600" />
              بيانات الشحن والتوصيل:
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between bg-white p-2.5 rounded-lg border border-blue-200">
                <span className="text-xs font-bold text-slate-700">شركة الشحن:</span>
                <span className="text-sm font-black text-blue-950">
                  {invoice.shippingCompany || 'شحن خاص / عادي'}
                </span>
              </div>

              {/* Explicit requirement: سعر الشحن بجوار اسم الشركة */}
              <div className="flex items-center justify-between bg-white p-2.5 rounded-lg border border-blue-200">
                <span className="text-xs font-bold text-slate-700">تكلفة الشحن المقررة:</span>
                <span className="text-sm font-black text-blue-700">
                  {Number(invoice.shippingCost || 0).toLocaleString()} ج.م
                </span>
              </div>
            </div>
          </div>

          <div className="text-[11px] text-blue-800 font-medium mt-2 flex items-center gap-1">
            <CheckCircle className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span>يتم تسليم الأوردر ومتابعة البوليصة عبر {invoice.shippingCompany || 'مندوب الشحن'}</span>
          </div>
        </div>
      </div>

      {/* Ordered Items Table */}
      <div className="mb-6 rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full text-right border-collapse text-xs sm:text-sm">
          <thead>
            <tr
              className="text-white font-bold"
              style={{ backgroundColor: primaryColor }}
            >
              <th className="py-2.5 px-3 w-10 text-center">#</th>
              <th className="py-2.5 px-4">بيان المنتج المطلوب</th>
              <th className="py-2.5 px-3 w-20 text-center">الكمية</th>
              <th className="py-2.5 px-3 w-28 text-center">سعر الوحدة</th>
              <th className="py-2.5 px-4 w-32 text-center">إجمالي السعر</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 bg-white">
            {invoice.items.map((item, idx) => (
              <tr
                key={item.id}
                className={idx % 2 === 1 ? 'bg-slate-50/70' : 'bg-white'}
              >
                <td className="py-3 px-3 text-center font-bold text-slate-400 text-xs">
                  {idx + 1}
                </td>
                <td className="py-3 px-4 font-bold text-slate-800">
                  {item.name || 'منتج غير محدد'}
                </td>
                <td className="py-3 px-3 text-center font-black text-slate-900">
                  {item.quantity}
                </td>
                <td className="py-3 px-3 text-center text-slate-700">
                  {Number(item.price).toLocaleString()} ج.م
                </td>
                <td className="py-3 px-4 text-center font-black text-slate-950">
                  {(item.quantity * item.price).toLocaleString()} ج.م
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Financial Breakdown & Totals */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-start pb-6 border-b-2 border-slate-200">
        {/* Left Side: Tafqeet, Notes & Barcode */}
        <div className="sm:col-span-7 space-y-4">
          {customization.showTafqeet && (
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <span className="font-bold text-slate-500 block mb-0.5">
                المبلغ الإجمالي كتابةً بالحروف:
              </span>
              <span className="font-black text-slate-900 text-sm">
                {numberToArabicWords(invoice.total, 'ج.م')}
              </span>
            </div>
          )}

          {/* Barcode & QR Code Section */}
          <div className="flex items-center gap-6 pt-1">
            {customization.showBarcode && (
              <div>
                <div className="flex items-center gap-[2px] h-10 w-44">
                  {[6, 2, 8, 4, 10, 3, 7, 2, 9, 3, 5, 2, 8, 4, 9, 3, 6, 2, 7, 4, 8, 2, 9, 3, 5, 2].map(
                    (w, i) => (
                      <div key={i} className="bg-black h-full" style={{ width: `${w * 0.8}px` }} />
                    )
                  )}
                </div>
                <span className="font-mono text-[10px] block mt-1 tracking-wider text-slate-600">
                  {invoice.invoiceNumber}
                </span>
              </div>
            )}

            {customization.showQrCode && (
              <div className="flex items-center gap-2 border border-slate-200 p-1.5 rounded-lg bg-white shadow-2xs">
                {/* SVG QR Code Simulation */}
                <svg className="w-12 h-12" viewBox="0 0 100 100">
                  <rect width="100" height="100" fill="#fff" />
                  <path
                    d="M10,10 h30 v30 h-30 z M15,15 v20 h20 v-20 z M20,20 h10 v10 h-10 z"
                    fill="#000"
                  />
                  <path
                    d="M60,10 h30 v30 h-30 z M65,15 v20 h20 v-20 z M70,20 h10 v10 h-10 z"
                    fill="#000"
                  />
                  <path
                    d="M10,60 h30 v30 h-30 z M15,65 v20 h20 v-20 z M20,70 h10 v10 h-10 z"
                    fill="#000"
                  />
                  <rect x="50" y="50" width="10" height="10" fill="#000" />
                  <rect x="65" y="65" width="10" height="10" fill="#000" />
                  <rect x="80" y="50" width="10" height="10" fill="#000" />
                  <rect x="50" y="80" width="10" height="10" fill="#000" />
                  <rect x="75" y="80" width="15" height="10" fill="#000" />
                </svg>
                <div className="text-[10px] text-slate-500 font-bold leading-tight">
                  مسح للتحقق<br />من الأوردر
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Totals Card */}
        <div className="sm:col-span-5 bg-slate-50 rounded-xl border border-slate-200 p-4 space-y-2 text-xs sm:text-sm">
          <div className="flex justify-between text-slate-600">
            <span>إجمالي المنتجات:</span>
            <span className="font-bold text-slate-900">
              {invoice.subtotal.toLocaleString()} ج.م
            </span>
          </div>

          {/* Shipping fee right beside the company name (Required by prompt) */}
          <div className="flex justify-between text-blue-900 bg-blue-100/70 p-2 rounded-lg font-bold">
            <span className="flex items-center gap-1">
              <Truck className="w-3.5 h-3.5 text-blue-600" />
              الشحن ({invoice.shippingCompany || 'شركة الشحن'}):
            </span>
            <span className="font-black text-blue-950">
              +{Number(invoice.shippingCost || 0).toLocaleString()} ج.م
            </span>
          </div>

          {invoice.discount > 0 && (
            <div className="flex justify-between text-red-600 font-bold">
              <span>قيمة الخصم:</span>
              <span>-{invoice.discount.toLocaleString()} ج.م</span>
            </div>
          )}

          {invoice.taxRate > 0 && (
            <div className="flex justify-between text-slate-600">
              <span>ضريبة القيمة المضافة ({invoice.taxRate}%):</span>
              <span className="font-bold">
                +{(((invoice.subtotal - invoice.discount) * invoice.taxRate) / 100).toLocaleString()} ج.م
              </span>
            </div>
          )}

          <div
            className="pt-3 mt-1 border-t-2 border-slate-300 flex justify-between items-center text-sm sm:text-base font-black"
            style={{ color: primaryColor }}
          >
            <span>المبلغ الإجمالي المستحق:</span>
            <span className="text-xl font-black">
              {invoice.total.toLocaleString()} ج.م
            </span>
          </div>
        </div>
      </div>

      {/* Footer: Stamp, Signatures & Return Policy */}
      <div className="pt-6 grid grid-cols-1 sm:grid-cols-12 gap-6 items-end">
        {/* Terms & Return Policy */}
        <div className="sm:col-span-8">
          {customization.showTerms && (
            <div>
              <span className="text-xs font-black text-slate-800 block mb-1">
                شروط وضمان الاستلام والاستبدال:
              </span>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {sellerCompany.footerPolicy ||
                  'البضاعة المباعة ترد وتستبدل خلال 14 يوماً من تاريخ الاستلام في حالتها الأصلية مع إرفاق الفاتورة. يرجى مراجعة محتويات الشحنة مع مندوب التوصيل قبل السداد.'}
              </p>
            </div>
          )}
        </div>

        {/* Store Stamp & Signature */}
        {customization.showStamp && (
          <div className="sm:col-span-4 flex flex-col items-center justify-center text-center">
            <div className="w-32 h-16 border-2 border-dashed border-slate-300 rounded-xl flex items-center justify-center text-slate-300 text-xs font-bold relative mb-1">
              {/* Simulated Stamp SVG */}
              <div
                className="w-20 h-12 border-2 rounded-lg flex flex-col items-center justify-center rotate-[-8deg] opacity-70"
                style={{ borderColor: primaryColor, color: primaryColor }}
              >
                <span className="text-[9px] font-black">{sellerCompany.name}</span>
                <span className="text-[8px] font-bold">معتمد رسمياً</span>
              </div>
            </div>
            <span className="text-[11px] font-bold text-slate-600">
              ختم وتوقيع المسؤول
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
