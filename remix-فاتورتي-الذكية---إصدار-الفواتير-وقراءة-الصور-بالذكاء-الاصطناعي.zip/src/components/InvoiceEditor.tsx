import React, { useState, useEffect } from 'react';
import {
  Plus,
  Trash2,
  Printer,
  Save,
  RotateCcw,
  Sparkles,
  Truck,
  User,
  Phone,
  MapPin,
  FileText,
  DollarSign,
  Tag,
  Star,
  Check,
  ChevronDown,
  Building,
} from 'lucide-react';
import {
  Customer,
  Invoice,
  InvoiceItem,
  PaymentMethod,
  ShippingCompany,
  SellerCompany,
} from '../types';
import { numberToArabicWords } from '../utils/tafqeet';

interface InvoiceEditorProps {
  invoice: Invoice;
  setInvoice: React.Dispatch<React.SetStateAction<Invoice>>;
  shippingCompanies: ShippingCompany[];
  customers: Customer[];
  sellerCompanies: SellerCompany[];
  onSaveInvoice: () => void;
  onPrintPreview: () => void;
  onResetInvoice: () => void;
  onOpenAiScanner: () => void;
  onQuickAddShippingCompany: (name: string, cost: number) => void;
}

export const InvoiceEditor: React.FC<InvoiceEditorProps> = ({
  invoice,
  setInvoice,
  shippingCompanies,
  customers,
  sellerCompanies,
  onSaveInvoice,
  onPrintPreview,
  onResetInvoice,
  onOpenAiScanner,
  onQuickAddShippingCompany,
}) => {
  const [showCustomerSuggestions, setShowCustomerSuggestions] = useState(false);
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [showAddCompanyModal, setShowAddCompanyModal] = useState(false);
  const [newCompanyName, setNewCompanyName] = useState('');
  const [newCompanyCost, setNewCompanyCost] = useState<number>(50);

  // Auto calculate subtotal and total
  useEffect(() => {
    const subtotal = invoice.items.reduce(
      (sum, item) => sum + (Number(item.quantity) || 0) * (Number(item.price) || 0),
      0
    );

    const shipping = Number(invoice.shippingCost) || 0;
    const discount = Number(invoice.discount) || 0;
    const taxRate = Number(invoice.taxRate) || 0;

    const afterDiscount = Math.max(0, subtotal - discount);
    const taxAmount = (afterDiscount * taxRate) / 100;
    const total = Math.max(0, afterDiscount + taxAmount + shipping);

    setInvoice((prev) => ({
      ...prev,
      subtotal,
      total,
    }));
  }, [
    invoice.items,
    invoice.shippingCost,
    invoice.discount,
    invoice.taxRate,
    setInvoice,
  ]);

  // Handle Items modification
  const handleItemChange = (
    index: number,
    field: keyof InvoiceItem,
    value: string | number
  ) => {
    const updated = [...invoice.items];
    const current = { ...updated[index], [field]: value };

    if (field === 'quantity' || field === 'price') {
      const q = field === 'quantity' ? Number(value) || 0 : Number(current.quantity) || 0;
      const p = field === 'price' ? Number(value) || 0 : Number(current.price) || 0;
      current.total = q * p;
    }

    updated[index] = current;
    setInvoice((prev) => ({ ...prev, items: updated }));
  };

  const handleAddItem = () => {
    const newItem: InvoiceItem = {
      id: 'item-' + Date.now(),
      name: '',
      quantity: 1,
      price: 0,
      total: 0,
    };
    setInvoice((prev) => ({
      ...prev,
      items: [...prev.items, newItem],
    }));
  };

  const handleRemoveItem = (index: number) => {
    if (invoice.items.length <= 1) {
      // Clear instead of removing last item
      setInvoice((prev) => ({
        ...prev,
        items: [{ id: 'item-1', name: '', quantity: 1, price: 0, total: 0 }],
      }));
      return;
    }
    const updated = invoice.items.filter((_, i) => i !== index);
    setInvoice((prev) => ({ ...prev, items: updated }));
  };

  // Select customer from database
  const handleSelectCustomer = (customer: Customer) => {
    setInvoice((prev) => ({
      ...prev,
      customerId: customer.id,
      customerName: customer.name,
      customerPhone: customer.phone,
      customerAddress: customer.address,
      customerCity: customer.city || prev.customerCity,
    }));
    setShowCustomerSuggestions(false);
  };

  // Select shipping company
  const handleSelectShippingCompany = (company: ShippingCompany) => {
    setInvoice((prev) => ({
      ...prev,
      shippingCompany: company.name,
      shippingCost: company.defaultCost,
    }));
  };

  const handleCreateNewCompany = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompanyName.trim()) return;
    onQuickAddShippingCompany(newCompanyName.trim(), newCompanyCost);
    setInvoice((prev) => ({
      ...prev,
      shippingCompany: newCompanyName.trim(),
      shippingCost: newCompanyCost,
    }));
    setNewCompanyName('');
    setShowAddCompanyModal(false);
  };

  const pinnedCompanies = shippingCompanies.filter((c) => c.isPinned);

  // Filter customer suggestions
  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(customerSearchQuery.toLowerCase()) ||
      c.phone.includes(customerSearchQuery)
  );

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* Top Banner & Quick Controls */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 rounded-2xl p-4 sm:p-6 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-white/20 text-white text-xs px-2.5 py-0.5 rounded-full font-semibold">
              رقم الفاتورة: {invoice.invoiceNumber}
            </span>
            {invoice.extractedFromImage && (
              <span className="bg-emerald-500/80 text-white text-xs px-2.5 py-0.5 rounded-full font-semibold flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                مستخرجة بالذكاء الاصطناعي
              </span>
            )}
          </div>
          <h2 className="text-xl sm:text-2xl font-black">محرر فواتير المبيعات والشحن</h2>
          <p className="text-xs sm:text-sm text-blue-100 mt-1">
            عدل بيانات العميل والمنتجات والشحن، وخصص المظهر قبل الطباعة
          </p>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
          <button
            type="button"
            onClick={onOpenAiScanner}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-white text-blue-800 hover:bg-blue-50 rounded-xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
          >
            <Sparkles className="w-4 h-4 text-blue-600" />
            استخراج من صورة جديدة
          </button>

          <button
            type="button"
            onClick={onPrintPreview}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-bold text-xs sm:text-sm shadow-md shadow-emerald-900/20 flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
          >
            <Printer className="w-4 h-4" />
            معاينة وطباعة الفاتورة
          </button>
        </div>
      </div>

      {/* Main Grid: Customer Details & Order Header */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Customer Information Card */}
        <div className="md:col-span-8 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs relative">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
            <h3 className="font-bold text-slate-800 text-base flex items-center gap-2">
              <User className="w-4 h-4 text-blue-600" />
              بيانات العميل المستلم
            </h3>

            {/* Quick customer pick dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowCustomerSuggestions(!showCustomerSuggestions)}
                className="text-xs bg-blue-50 hover:bg-blue-100 text-blue-700 px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 border border-blue-200 transition-colors"
              >
                <span>اختيار من سجل العملاء ({customers.length})</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {showCustomerSuggestions && (
                <div className="absolute left-0 top-full mt-1 w-72 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-30">
                  <input
                    type="text"
                    placeholder="ابحث بالاسم أو الهاتف..."
                    value={customerSearchQuery}
                    onChange={(e) => setCustomerSearchQuery(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 border border-slate-200 rounded-lg mb-2 focus:ring-1 focus:ring-blue-500 outline-none"
                    autoFocus
                  />
                  <div className="max-h-48 overflow-y-auto divide-y divide-slate-100">
                    {filteredCustomers.length > 0 ? (
                      filteredCustomers.map((c) => (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => handleSelectCustomer(c)}
                          className="w-full text-right p-2 hover:bg-blue-50 rounded-lg text-xs transition-colors flex flex-col"
                        >
                          <span className="font-bold text-slate-800">{c.name}</span>
                          <span className="text-slate-500 text-[11px]" dir="ltr">
                            {c.phone}
                          </span>
                          <span className="text-slate-400 text-[10px] truncate">{c.address}</span>
                        </button>
                      ))
                    ) : (
                      <div className="p-3 text-center text-xs text-slate-400">لا يوجد عميل بهذا الاسم</div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Customer Name */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                اسم العميل <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="مثال: أحمد عبد الله الشناوي"
                  value={invoice.customerName}
                  onChange={(e) =>
                    setInvoice((prev) => ({ ...prev, customerName: e.target.value }))
                  }
                  className="w-full px-3 py-2 pr-9 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
                <User className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
              </div>
            </div>

            {/* Customer Phone */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                رقم الهاتف / الموبايل <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="010XXXXXXXX أو 011..."
                  dir="ltr"
                  value={invoice.customerPhone}
                  onChange={(e) =>
                    setInvoice((prev) => ({ ...prev, customerPhone: e.target.value }))
                  }
                  className="w-full px-3 py-2 pr-9 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-right"
                />
                <Phone className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
              </div>
            </div>

            {/* Customer Address */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                العنوان بالتفصيل <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="الشارع، رقم العمارة، رقم الشقة، علامة مميزة..."
                  value={invoice.customerAddress}
                  onChange={(e) =>
                    setInvoice((prev) => ({ ...prev, customerAddress: e.target.value }))
                  }
                  className="w-full px-3 py-2 pr-9 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
                <MapPin className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
              </div>
            </div>

            {/* City / Governorate */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                المحافظة / المدينة
              </label>
              <input
                type="text"
                placeholder="مثال: القاهرة، الجيزة، الإسكندرية..."
                value={invoice.customerCity || ''}
                onChange={(e) =>
                  setInvoice((prev) => ({ ...prev, customerCity: e.target.value }))
                }
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>

            {/* Delivery Notes */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                تعليمات التوصيل للمندوب
              </label>
              <input
                type="text"
                placeholder="مثال: يرجى الاتصال قبل الوصول بنصف ساعة"
                value={invoice.notes || ''}
                onChange={(e) =>
                  setInvoice((prev) => ({ ...prev, notes: e.target.value }))
                }
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Invoice Meta & Settings */}
        <div className="md:col-span-4 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-800 text-base flex items-center gap-2 pb-3 border-b border-slate-100">
            <FileText className="w-4 h-4 text-blue-600" />
            بيانات الفاتورة والدفع
          </h3>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">رقم الفاتورة</label>
            <input
              type="text"
              value={invoice.invoiceNumber}
              onChange={(e) =>
                setInvoice((prev) => ({ ...prev, invoiceNumber: e.target.value }))
              }
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm font-mono font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">تاريخ الفاتورة</label>
            <input
              type="date"
              value={invoice.date}
              onChange={(e) =>
                setInvoice((prev) => ({ ...prev, date: e.target.value }))
              }
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">طريقة الدفع والتحصيل</label>
            <select
              value={invoice.paymentMethod}
              onChange={(e) =>
                setInvoice((prev) => ({
                  ...prev,
                  paymentMethod: e.target.value as PaymentMethod,
                }))
              }
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            >
              <option value="cash_on_delivery">💵 الدفع نقدًا عند الاستلام (COD)</option>
              <option value="vodafone_cash">📱 فودافون كاش / محافظ إلكترونية</option>
              <option value="instapay">⚡ إنستاباي (InstaPay)</option>
              <option value="bank_transfer">🏦 تحويل بنكي مسبق</option>
              <option value="card">💳 بطاقة بنكية / فيزا</option>
              <option value="prepaid">✅ مدفوع مسبقاً</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">المتجر / الشركة المصدرة</label>
            <select
              value={invoice.sellerCompanyId || sellerCompanies[0]?.id || ''}
              onChange={(e) =>
                setInvoice((prev) => ({ ...prev, sellerCompanyId: e.target.value }))
              }
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            >
              {sellerCompanies.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.isDefault ? '(الافتراضي)' : ''}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Ordered Products Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Tag className="w-4 h-4 text-blue-600" />
              المنتجات والأصناف المطلوبة
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              يمكنك كتابة اسم المنتج وتحديد الكمية وسعر القطعة وسيحسب الإجمالي تلقائياً
            </p>
          </div>

          <button
            type="button"
            onClick={handleAddItem}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            إضافة منتج آخر
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-slate-100/80 text-slate-700 text-xs font-bold border-b border-slate-200">
                <th className="py-3 px-4 w-12 text-center">#</th>
                <th className="py-3 px-4 min-w-[240px]">بيان المنتج / الصنف</th>
                <th className="py-3 px-4 w-28 text-center">الكمية</th>
                <th className="py-3 px-4 w-36 text-center">سعر الوحدة (ج.م)</th>
                <th className="py-3 px-4 w-36 text-center">الإجمالي (ج.م)</th>
                <th className="py-3 px-4 w-14 text-center">حذف</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {invoice.items.map((item, idx) => (
                <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 text-center font-bold text-slate-400 text-xs">
                    {idx + 1}
                  </td>

                  <td className="py-3 px-4">
                    <input
                      type="text"
                      placeholder="اسم المنتج أو وصفه ومقاسه ولونه..."
                      value={item.name}
                      onChange={(e) => handleItemChange(idx, 'name', e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-sm focus:ring-1 focus:ring-blue-500 outline-none"
                    />
                  </td>

                  <td className="py-3 px-4">
                    <div className="flex items-center justify-center">
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) =>
                          handleItemChange(idx, 'quantity', Math.max(1, parseInt(e.target.value) || 1))
                        }
                        className="w-20 text-center px-2 py-1.5 border border-slate-200 rounded-lg text-sm font-bold focus:ring-1 focus:ring-blue-500 outline-none"
                      />
                    </div>
                  </td>

                  <td className="py-3 px-4">
                    <div className="flex items-center justify-center">
                      <input
                        type="number"
                        min="0"
                        step="any"
                        placeholder="0"
                        value={item.price === 0 ? '' : item.price}
                        onChange={(e) =>
                          handleItemChange(idx, 'price', parseFloat(e.target.value) || 0)
                        }
                        className="w-28 text-center px-2 py-1.5 border border-slate-200 rounded-lg text-sm font-bold text-slate-900 focus:ring-1 focus:ring-blue-500 outline-none"
                      />
                    </div>
                  </td>

                  <td className="py-3 px-4 text-center font-black text-slate-900">
                    {(item.quantity * item.price).toLocaleString()} ج.م
                  </td>

                  <td className="py-3 px-4 text-center">
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(idx)}
                      className="text-slate-400 hover:text-red-600 p-1 rounded-lg hover:bg-red-50 transition-colors"
                      title="حذف هذا الصنف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Add row footer */}
        <div className="p-3 bg-slate-50/50 border-t border-slate-100 flex justify-start">
          <button
            type="button"
            onClick={handleAddItem}
            className="text-blue-600 hover:text-blue-700 text-xs font-bold flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-blue-50 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            + إضافة صنف إضافي
          </button>
        </div>
      </div>

      {/* Shipping & Financial Breakdown (Explicitly meeting user requirement: سعر الشحن بجواره اسم الشركة) */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Shipping Company & Cost Section */}
        <div className="md:col-span-7 bg-white rounded-2xl border border-blue-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-blue-100">
            <div>
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <Truck className="w-5 h-5 text-blue-600" />
                بيانات شركة الشحن وسعر التوصيل
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                يظهر سعر الشحن بجوار اسم الشركة في الفاتورة المطبوعة مباشرة
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowAddCompanyModal(true)}
              className="text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              إضافة شركة جديدة
            </button>
          </div>

          {/* Quick Pinned Companies Chips */}
          <div>
            <label className="block text-xs font-bold text-slate-600 mb-2 flex items-center gap-1.5">
              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              الشركات المثبتة في البرنامج (اضغط للاختيار السريع):
            </label>
            <div className="flex flex-wrap gap-2">
              {pinnedCompanies.map((c) => {
                const isSelected = invoice.shippingCompany === c.name;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => handleSelectShippingCompany(c)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border ${
                      isSelected
                        ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300'
                    }`}
                  >
                    <span>{c.name}</span>
                    <span
                      className={`text-[11px] px-1.5 py-0.2 rounded-md ${
                        isSelected ? 'bg-blue-700 text-white' : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {c.defaultCost} ج.م
                    </span>
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Shipping Company & Cost Row (Directly adjacent as requested) */}
          <div className="p-4 bg-blue-50/60 rounded-xl border border-blue-200">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
              {/* Company Name */}
              <div className="sm:col-span-7">
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  اسم شركة الشحن المعتمدة
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="مثال: بوسطة، أرامكس، سمسا، مندوب خاص..."
                    value={invoice.shippingCompany}
                    onChange={(e) =>
                      setInvoice((prev) => ({ ...prev, shippingCompany: e.target.value }))
                    }
                    className="w-full px-3 py-2 pr-9 border border-blue-300 rounded-xl text-sm font-bold text-slate-900 bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                  <Truck className="w-4 h-4 text-blue-500 absolute right-3 top-3 pointer-events-none" />
                </div>
              </div>

              {/* Shipping Cost (Beside Company Name) */}
              <div className="sm:col-span-5">
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  سعر / مصاريف الشحن
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={invoice.shippingCost === 0 ? '' : invoice.shippingCost}
                    onChange={(e) =>
                      setInvoice((prev) => ({
                        ...prev,
                        shippingCost: parseFloat(e.target.value) || 0,
                      }))
                    }
                    className="w-full px-3 py-2 pr-9 border border-blue-300 rounded-xl text-sm font-black text-blue-900 bg-white focus:ring-2 focus:ring-blue-500 outline-none text-left"
                    dir="ltr"
                  />
                  <span className="absolute right-3 top-2.5 text-xs font-bold text-blue-600">
                    ج.م
                  </span>
                </div>
              </div>
            </div>
            <p className="text-[11px] text-blue-700 mt-2 font-medium">
              💡 يظهر في الفاتورة: "الشحن ({invoice.shippingCompany || 'شركة الشحن'}): {invoice.shippingCost} ج.م"
            </p>
          </div>
        </div>

        {/* Financial Summary & Totals */}
        <div className="md:col-span-5 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
          <h3 className="font-bold text-slate-900 text-base pb-2 border-b border-slate-100 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-blue-600" />
            الحسابات والإجمالي النهائي
          </h3>

          <div className="space-y-2.5 text-sm">
            <div className="flex items-center justify-between text-slate-600">
              <span>إجمالي المنتجات:</span>
              <span className="font-bold text-slate-900">
                {invoice.subtotal.toLocaleString()} ج.م
              </span>
            </div>

            <div className="flex items-center justify-between text-blue-800 bg-blue-50/70 p-2 rounded-lg font-medium">
              <span className="flex items-center gap-1">
                <Truck className="w-3.5 h-3.5 text-blue-600" />
                الشحن ({invoice.shippingCompany || 'بدون تحديد'}):
              </span>
              <span className="font-black text-blue-900">
                +{Number(invoice.shippingCost || 0).toLocaleString()} ج.م
              </span>
            </div>

            {/* Discount */}
            <div className="flex items-center justify-between gap-3 text-slate-600">
              <span>الخصم (إن وجد):</span>
              <div className="flex items-center gap-1 w-28">
                <input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={invoice.discount === 0 ? '' : invoice.discount}
                  onChange={(e) =>
                    setInvoice((prev) => ({
                      ...prev,
                      discount: parseFloat(e.target.value) || 0,
                    }))
                  }
                  className="w-full text-center px-2 py-1 border border-slate-200 rounded-lg text-xs font-bold text-red-600 focus:ring-1 focus:ring-blue-500 outline-none"
                />
                <span className="text-xs text-slate-400">ج.م</span>
              </div>
            </div>

            {/* Tax */}
            <div className="flex items-center justify-between gap-3 text-slate-600">
              <span>ضريبة القيمة المضافة:</span>
              <div className="flex items-center gap-1 w-28">
                <input
                  type="number"
                  min="0"
                  max="100"
                  placeholder="0%"
                  value={invoice.taxRate === 0 ? '' : invoice.taxRate}
                  onChange={(e) =>
                    setInvoice((prev) => ({
                      ...prev,
                      taxRate: parseFloat(e.target.value) || 0,
                    }))
                  }
                  className="w-full text-center px-2 py-1 border border-slate-200 rounded-lg text-xs font-bold focus:ring-1 focus:ring-blue-500 outline-none"
                />
                <span className="text-xs text-slate-400">%</span>
              </div>
            </div>

            <div className="pt-3 border-t-2 border-slate-200 flex items-center justify-between">
              <span className="font-black text-slate-900 text-base">
                المبلغ الكلي المستحق:
              </span>
              <div className="text-left">
                <span className="text-xl sm:text-2xl font-black text-emerald-600">
                  {invoice.total.toLocaleString()}
                </span>
                <span className="text-xs font-bold text-slate-500 mr-1">ج.م</span>
              </div>
            </div>

            {/* Arabic Tafqeet in words */}
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs text-slate-700">
              <span className="text-[11px] text-slate-400 block mb-0.5 font-bold">
                المبلغ كتابة بالحروف (للطباعة):
              </span>
              <span className="font-bold text-blue-900">
                {numberToArabicWords(invoice.total, 'ج.م')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Bottom Action Toolbar */}
      <div className="sticky bottom-4 bg-white/95 backdrop-blur-md border border-slate-200 p-4 rounded-2xl shadow-xl flex flex-wrap items-center justify-between gap-3 z-30">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onResetInvoice}
            className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            تفريغ / فاتورة جديدة
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onSaveInvoice}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 shadow-sm transition-all"
          >
            <Save className="w-4 h-4" />
            حفظ الفاتورة في الأرشيف
          </button>

          <button
            type="button"
            onClick={onPrintPreview}
            className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 shadow-md shadow-emerald-600/20 transition-all hover:scale-[1.02]"
          >
            <Printer className="w-4 h-4" />
            معاينة وتخصيص الطباعة 🖨️
          </button>
        </div>
      </div>

      {/* Modal: Quick Add Shipping Company */}
      {showAddCompanyModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="font-bold text-lg text-slate-900 mb-1 flex items-center gap-2">
              <Truck className="w-5 h-5 text-blue-600" />
              إضافة شركة شحن جديدة
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              أدخل اسم شركة الشحن وتكلفة الشحن الافتراضية لحفظها في البرنامج
            </p>

            <form onSubmit={handleCreateNewCompany} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم الشركة <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="مثال: شحن الصعيد إكسبريس"
                  value={newCompanyName}
                  onChange={(e) => setNewCompanyName(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  تكلفة الشحن الافتراضية (ج.م)
                </label>
                <input
                  type="number"
                  min="0"
                  value={newCompanyCost}
                  onChange={(e) => setNewCompanyCost(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddCompanyModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-sm"
                >
                  حفظ وتثبيت الشركة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
