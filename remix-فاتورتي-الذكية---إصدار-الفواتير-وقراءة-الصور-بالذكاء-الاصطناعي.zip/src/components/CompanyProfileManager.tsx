import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Phone,
  MapPin,
  FileText,
  Check,
  Edit2,
  Upload,
  Image as ImageIcon,
  ShieldCheck,
  Save,
  RotateCcw,
} from 'lucide-react';
import { SellerCompany } from '../types';

interface CompanyProfileManagerProps {
  sellerCompanies: SellerCompany[];
  onSaveCompany: (company: SellerCompany) => void;
  onSetDefaultCompany: (id: string) => void;
}

export const CompanyProfileManager: React.FC<CompanyProfileManagerProps> = ({
  sellerCompanies,
  onSaveCompany,
  onSetDefaultCompany,
}) => {
  const [selectedCompany, setSelectedCompany] = useState<SellerCompany>(
    sellerCompanies.find((c) => c.isDefault) || sellerCompanies[0]
  );
  const [isEditing, setIsEditing] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Form states
  const [name, setName] = useState(selectedCompany.name);
  const [phone, setPhone] = useState(selectedCompany.phone);
  const [address, setAddress] = useState(selectedCompany.address);
  const [taxId, setTaxId] = useState(selectedCompany.taxId || '');
  const [commercialReg, setCommercialReg] = useState(selectedCompany.commercialReg || '');
  const [footerPolicy, setFooterPolicy] = useState(selectedCompany.footerPolicy || '');
  const [logoUrl, setLogoUrl] = useState(selectedCompany.logoUrl || '');
  const [currency, setCurrency] = useState(selectedCompany.currency || 'ج.م');

  const handleSelectCompany = (comp: SellerCompany) => {
    setSelectedCompany(comp);
    setName(comp.name);
    setPhone(comp.phone);
    setAddress(comp.address);
    setTaxId(comp.taxId || '');
    setCommercialReg(comp.commercialReg || '');
    setFooterPolicy(comp.footerPolicy || '');
    setLogoUrl(comp.logoUrl || '');
    setCurrency(comp.currency || 'ج.م');
    setIsEditing(false);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        setLogoUrl(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const updated: SellerCompany = {
      ...selectedCompany,
      name: name.trim(),
      phone: phone.trim(),
      address: address.trim(),
      taxId: taxId.trim() || undefined,
      commercialReg: commercialReg.trim() || undefined,
      footerPolicy: footerPolicy.trim() || undefined,
      logoUrl: logoUrl.trim() || undefined,
      currency,
    };

    onSaveCompany(updated);
    setSelectedCompany(updated);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleAddNewCompany = () => {
    const newComp: SellerCompany = {
      id: 'seller-' + Date.now(),
      name: 'متجر جديد',
      phone: '01000000000',
      address: 'القاهرة، مصر',
      currency: 'ج.م',
      footerPolicy: 'البضاعة المباعة ترد وتستبدل خلال 14 يوماً مع إرفاق الفاتورة الأصلية.',
      isDefault: false,
    };
    onSaveCompany(newComp);
    handleSelectCompany(newComp);
    setIsEditing(true);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-16">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-900 rounded-2xl p-6 text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black">بيانات المتجر والشركات المصدرة للفواتير</h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            خصص اسم المتجر، اللوجو، السجل التجاري، البطاقة الضريبية وسياسة الاسترجاع
          </p>
        </div>

        <button
          type="button"
          onClick={handleAddNewCompany}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          إضافة شركة / فرع جديد
        </button>
      </div>

      {/* Company Switcher Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {sellerCompanies.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => handleSelectCompany(c)}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 border ${
              selectedCompany.id === c.id
                ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>{c.name}</span>
            {c.isDefault && (
              <span className="text-[10px] bg-white/20 text-white px-1.5 py-0.2 rounded-full">
                الرئيسي
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Company Profile Edit Form */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <form onSubmit={handleSave} className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-900 text-lg">{name || 'تفاصيل المتجر'}</h3>
              <p className="text-xs text-slate-500">تظهر هذه البيانات في ترويسة الفاتورة المطبوعة</p>
            </div>

            <div className="flex items-center gap-3">
              {!selectedCompany.isDefault && (
                <button
                  type="button"
                  onClick={() => onSetDefaultCompany(selectedCompany.id)}
                  className="px-3 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors"
                >
                  تعيين كمتجر افتراضي للفواتير
                </button>
              )}

              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all"
              >
                <Save className="w-4 h-4" />
                حفظ التعديلات
              </button>
            </div>
          </div>

          {saveSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              تم حفظ بيانات الشركة بنجاح وستظهر في كل الفواتير الجديدة!
            </div>
          )}

          {/* Logo Section */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="w-20 h-20 rounded-2xl bg-white border border-slate-300 flex items-center justify-center overflow-hidden shrink-0 shadow-xs">
              {logoUrl ? (
                <img src={logoUrl} alt="Store Logo" className="max-h-full max-w-full object-contain" />
              ) : (
                <ImageIcon className="w-8 h-8 text-slate-300" />
              )}
            </div>

            <div className="space-y-2 flex-1">
              <span className="text-xs font-bold text-slate-700 block">شعار المتجر (Logo)</span>
              <div className="flex items-center gap-2">
                <label className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-bold text-slate-700 cursor-pointer flex items-center gap-1.5 shadow-xs">
                  <Upload className="w-3.5 h-3.5 text-blue-600" />
                  رفع صورة الشعار
                  <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                </label>
                {logoUrl && (
                  <button
                    type="button"
                    onClick={() => setLogoUrl('')}
                    className="text-xs text-red-600 hover:underline font-semibold"
                  >
                    حذف الشعار
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-400">يفضل صورة بخلفية شفافة PNG بدقة واضحة</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                اسم المتجر / الشركة <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                رقم الهاتف / خدمة العملاء <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                dir="ltr"
                required
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none text-right"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                العنوان والمقر الرئيسي
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                الرقم الضريبي (إن وجد)
              </label>
              <input
                type="text"
                value={taxId}
                onChange={(e) => setTaxId(e.target.value)}
                placeholder="مثال: 654-892-120"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                رقم السجل التجاري (إن وجد)
              </label>
              <input
                type="text"
                value={commercialReg}
                onChange={(e) => setCommercialReg(e.target.value)}
                placeholder="مثال: 108420"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                سياسة الاسترجاع والضمان (تظهر بأسفل الفاتورة)
              </label>
              <textarea
                rows={2}
                value={footerPolicy}
                onChange={(e) => setFooterPolicy(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
