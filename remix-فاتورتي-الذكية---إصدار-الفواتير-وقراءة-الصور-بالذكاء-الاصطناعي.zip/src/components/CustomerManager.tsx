import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Phone,
  MapPin,
  FileText,
  Calendar,
  DollarSign,
  TrendingUp,
  Printer,
  ChevronLeft,
  X,
  Edit2,
  Trash2,
  CheckCircle,
  Truck,
  ExternalLink,
  UserCheck,
} from 'lucide-react';
import { Customer, Invoice } from '../types';

interface CustomerManagerProps {
  customers: Customer[];
  invoices: Invoice[];
  onSaveCustomer: (customer: Customer) => void;
  onDeleteCustomer: (id: string) => void;
  onCreateInvoiceForCustomer: (customer: Customer) => void;
  onViewInvoice: (invoice: Invoice) => void;
}

export const CustomerManager: React.FC<CustomerManagerProps> = ({
  customers,
  invoices,
  onSaveCustomer,
  onDeleteCustomer,
  onCreateInvoiceForCustomer,
  onViewInvoice,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  // Form states
  const [formName, setFormName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formSecondaryPhone, setFormSecondaryPhone] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formCity, setFormCity] = useState('');
  const [formNotes, setFormNotes] = useState('');

  const openAddModal = (customer?: Customer) => {
    if (customer) {
      setEditingCustomer(customer);
      setFormName(customer.name);
      setFormPhone(customer.phone);
      setFormSecondaryPhone(customer.secondaryPhone || '');
      setFormAddress(customer.address);
      setFormCity(customer.city || '');
      setFormNotes(customer.notes || '');
    } else {
      setEditingCustomer(null);
      setFormName('');
      setFormPhone('');
      setFormSecondaryPhone('');
      setFormAddress('');
      setFormCity('');
      setFormNotes('');
    }
    setShowAddModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formPhone.trim()) return;

    const newCustomer: Customer = {
      id: editingCustomer ? editingCustomer.id : 'cust-' + Date.now(),
      name: formName.trim(),
      phone: formPhone.trim(),
      secondaryPhone: formSecondaryPhone.trim() || undefined,
      address: formAddress.trim(),
      city: formCity.trim() || undefined,
      notes: formNotes.trim() || undefined,
      createdAt: editingCustomer ? editingCustomer.createdAt : new Date().toISOString(),
    };

    onSaveCustomer(newCustomer);
    if (selectedCustomer && selectedCustomer.id === newCustomer.id) {
      setSelectedCustomer(newCustomer);
    }
    setShowAddModal(false);
  };

  // Calculate customer sales metrics
  const getCustomerInvoices = (customer: Customer): Invoice[] => {
    return invoices.filter(
      (inv) =>
        inv.customerId === customer.id ||
        (inv.customerPhone && inv.customerPhone === customer.phone) ||
        (inv.customerName && inv.customerName.trim() === customer.name.trim())
    );
  };

  const getCustomerMetrics = (customer: Customer) => {
    const custInvoices = getCustomerInvoices(customer);
    const totalSpent = custInvoices.reduce((sum, inv) => sum + (Number(inv.total) || 0), 0);
    const lastInvoice = custInvoices.sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    )[0];

    return {
      invoicesCount: custInvoices.length,
      totalSpent,
      lastInvoiceDate: lastInvoice ? lastInvoice.date : null,
      lastInvoice,
    };
  };

  // Filter customers
  const filteredCustomers = customers.filter((c) => {
    const q = searchQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.phone.includes(q) ||
      (c.address && c.address.toLowerCase().includes(q)) ||
      (c.city && c.city.toLowerCase().includes(q))
    );
  });

  // Overall stats
  const totalSpentAll = invoices.reduce((sum, inv) => sum + (Number(inv.total) || 0), 0);
  const activeCustomersCount = customers.filter(
    (c) => getCustomerInvoices(c).length > 0
  ).length;

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-16">
      {/* Top Banner & CRM Highlights */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 rounded-2xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-blue-500/20 text-blue-300 text-xs px-3 py-1 rounded-full font-bold border border-blue-400/30 flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5 text-blue-400" />
              نظام تتبع العملاء وسجل المبيعات
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black">
            قاعدة بيانات وتاريخ فواتير العملاء
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
            تتبع أسماء العملاء، أرقام هواتفهم، عناوينهم بالتفصيل، وسجل كافة الفواتير السابقة الصادرة لكل عميل
          </p>
        </div>

        <button
          type="button"
          onClick={() => openAddModal()}
          className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-sm shadow-md flex items-center gap-2 transition-all hover:scale-[1.02] shrink-0"
        >
          <Plus className="w-4 h-4" />
          إضافة عميل جديد
        </button>
      </div>

      {/* Quick Metrics Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-bold block">إجمالي العملاء المسجلين</span>
            <span className="text-2xl font-black text-slate-900">{customers.length}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-bold block">إجمالي مبيعات العملاء</span>
            <span className="text-2xl font-black text-emerald-600">
              {totalSpentAll.toLocaleString()} <span className="text-xs text-slate-500 font-normal">ج.م</span>
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-bold block">عملاء لديهم طلبات مسجلة</span>
            <span className="text-2xl font-black text-indigo-900">{activeCustomersCount}</span>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:max-w-md">
          <input
            type="text"
            placeholder="بحث باسم العميل، رقم الهاتف، أو العنوان..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2.5 pr-10 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5 pointer-events-none" />
        </div>

        <span className="text-xs text-slate-500 font-medium">
          يتم عرض {filteredCustomers.length} من أصل {customers.length} عميل
        </span>
      </div>

      {/* Customers List / Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 text-slate-700 text-xs font-bold border-b border-slate-200">
                <th className="py-3 px-4">اسم العميل</th>
                <th className="py-3 px-4">رقم الهاتف</th>
                <th className="py-3 px-4">العنوان والمحافظة</th>
                <th className="py-3 px-4 text-center">عدد الفواتير</th>
                <th className="py-3 px-4 text-center">إجمالي المشتريات</th>
                <th className="py-3 px-4 text-center">آخر طلب</th>
                <th className="py-3 px-4 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCustomers.length > 0 ? (
                filteredCustomers.map((customer) => {
                  const metrics = getCustomerMetrics(customer);
                  return (
                    <tr
                      key={customer.id}
                      className="hover:bg-blue-50/40 transition-colors cursor-pointer group"
                      onClick={() => setSelectedCustomer(customer)}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs shrink-0">
                            {customer.name.slice(0, 2)}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
                              {customer.name}
                            </div>
                            {customer.notes && (
                              <span className="text-[11px] text-slate-400 line-clamp-1">
                                {customer.notes}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono text-slate-700 text-xs" dir="ltr">
                        {customer.phone}
                        {customer.secondaryPhone && (
                          <span className="block text-[10px] text-slate-400">
                            {customer.secondaryPhone}
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-xs text-slate-600 max-w-xs">
                        <div className="line-clamp-2">
                          {customer.address}
                          {customer.city && (
                            <span className="font-bold text-slate-700 block mt-0.5">
                              ({customer.city})
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className="px-2.5 py-1 bg-slate-100 text-slate-800 rounded-full text-xs font-bold">
                          {metrics.invoicesCount} فواتير
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center font-black text-slate-900">
                        {metrics.totalSpent > 0 ? (
                          <span>
                            {metrics.totalSpent.toLocaleString()}{' '}
                            <span className="text-[11px] font-normal text-slate-500">ج.م</span>
                          </span>
                        ) : (
                          <span className="text-slate-400 text-xs">لا يوجد بعد</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center text-xs text-slate-500">
                        {metrics.lastInvoiceDate || '—'}
                      </td>

                      <td className="py-3 px-4 text-center" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setSelectedCustomer(customer)}
                            className="p-1.5 text-blue-600 hover:bg-blue-100 rounded-lg text-xs font-bold transition-colors"
                            title="عرض سجل فواتير العميل"
                          >
                            <FileText className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            onClick={() => onCreateInvoiceForCustomer(customer)}
                            className="px-2 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-xs font-bold transition-colors flex items-center gap-1"
                            title="إصدار فاتورة جديدة لهذا العميل"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            فاتورة
                          </button>

                          <button
                            type="button"
                            onClick={() => openAddModal(customer)}
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                            title="تعديل بيانات العميل"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`هل أنت متأكد من حذف العميل "${customer.name}"؟`)) {
                                onDeleteCustomer(customer.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="حذف العميل"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    لا يوجد عملاء يطابقون كلمة البحث
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Customer Profile & Sales History Modal / Drawer */}
      {selectedCustomer && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 flex flex-col">
            {/* Modal Header */}
            <div className="p-6 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-t-3xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-lg font-black text-white">
                  {selectedCustomer.name.slice(0, 2)}
                </div>
                <div>
                  <h3 className="text-xl font-black">{selectedCustomer.name}</h3>
                  <p className="text-xs text-blue-200 flex items-center gap-2 mt-0.5">
                    <span dir="ltr">{selectedCustomer.phone}</span>
                    {selectedCustomer.city && <span>• {selectedCustomer.city}</span>}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onCreateInvoiceForCustomer(selectedCustomer)}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all"
                >
                  <Plus className="w-4 h-4" />
                  إصدار فاتورة جديدة لهذا العميل
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedCustomer(null)}
                  className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6 flex-1">
              {/* Customer Contact Details Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-500 block mb-1">
                    أرقام الهواتف:
                  </span>
                  <div className="font-mono font-bold text-slate-900 text-sm" dir="ltr">
                    {selectedCustomer.phone}
                  </div>
                  {selectedCustomer.secondaryPhone && (
                    <div className="font-mono text-xs text-slate-500 mt-0.5" dir="ltr">
                      هاتف إضافي: {selectedCustomer.secondaryPhone}
                    </div>
                  )}
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 md:col-span-2">
                  <span className="text-xs font-bold text-slate-500 block mb-1">
                    العنوان التفصيلي:
                  </span>
                  <p className="text-xs font-semibold text-slate-800">
                    {selectedCustomer.address}
                    {selectedCustomer.city ? `، ${selectedCustomer.city}` : ''}
                  </p>
                </div>

                {selectedCustomer.notes && (
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 md:col-span-3 text-xs text-amber-900">
                    <span className="font-bold">ملاحظات العميل: </span>
                    {selectedCustomer.notes}
                  </div>
                )}
              </div>

              {/* Invoices History Section */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-black text-slate-900 text-base flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-600" />
                    سجل الفواتير والمبيعات السابقة ({getCustomerInvoices(selectedCustomer).length})
                  </h4>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                    إجمالي مشتريات: {getCustomerMetrics(selectedCustomer).totalSpent.toLocaleString()} ج.م
                  </span>
                </div>

                {getCustomerInvoices(selectedCustomer).length > 0 ? (
                  <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100">
                    {getCustomerInvoices(selectedCustomer).map((inv) => (
                      <div
                        key={inv.id}
                        className="p-4 bg-white hover:bg-slate-50 transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-black text-slate-900 text-sm">
                              #{inv.invoiceNumber}
                            </span>
                            <span className="text-xs text-slate-500">
                              {inv.date}
                            </span>
                            <span
                              className={`text-[11px] px-2 py-0.5 rounded-full font-bold ${
                                inv.status === 'delivered'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : inv.status === 'shipped'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              {inv.status === 'delivered'
                                ? 'تم التسليم'
                                : inv.status === 'shipped'
                                ? 'جاري الشحن'
                                : 'مؤكدة'}
                            </span>
                          </div>

                          <div className="text-xs text-slate-600">
                            {inv.items.map((i) => `${i.name} (${i.quantity}x)`).join('، ')}
                          </div>

                          <div className="text-xs text-blue-700 font-medium flex items-center gap-1">
                            <Truck className="w-3.5 h-3.5" />
                            <span>الشحن ({inv.shippingCompany}): {inv.shippingCost} ج.م</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                          <div className="text-left">
                            <span className="text-base font-black text-slate-900">
                              {inv.total.toLocaleString()} ج.م
                            </span>
                            <span className="block text-[10px] text-slate-400">
                              شامل الشحن
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              onViewInvoice(inv);
                              setSelectedCustomer(null);
                            }}
                            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            عرض وطباعة
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300">
                    <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-xs text-slate-500 font-bold mb-3">
                      لم يتم إصدار أي فواتير لهذا العميل حتى الآن
                    </p>
                    <button
                      type="button"
                      onClick={() => onCreateInvoiceForCustomer(selectedCustomer)}
                      className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold"
                    >
                      إصدار أول فاتورة للعميل
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
              <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                {editingCustomer ? 'تعديل بيانات العميل' : 'إضافة عميل جديد'}
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم العميل <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="الاسم بالكامل..."
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    رقم الهاتف الرئيسي <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="010XXXXXXXX"
                    dir="ltr"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    required
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none text-right"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    رقم هاتف إضافي (اختياري)
                  </label>
                  <input
                    type="text"
                    placeholder="012XXXXXXXX"
                    dir="ltr"
                    value={formSecondaryPhone}
                    onChange={(e) => setFormSecondaryPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none text-right"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  العنوان بالتفصيل
                </label>
                <input
                  type="text"
                  placeholder="الشارع، رقم العمارة، رقم الشقة، علامة مميزة..."
                  value={formAddress}
                  onChange={(e) => setFormAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  المحافظة / المدينة
                </label>
                <input
                  type="text"
                  placeholder="القاهرة، الجيزة، الإسكندرية..."
                  value={formCity}
                  onChange={(e) => setFormCity(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ملاحظات عن العميل
                </label>
                <textarea
                  rows={2}
                  placeholder="مثال: يفضل الشحن مع أرامكس، عميل دائم..."
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-sm"
                >
                  حفظ بيانات العميل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
