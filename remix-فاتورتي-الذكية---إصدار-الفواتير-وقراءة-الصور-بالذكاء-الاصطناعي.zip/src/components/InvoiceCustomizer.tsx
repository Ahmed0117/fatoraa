import React, { useRef } from 'react';
import {
  Palette,
  Type,
  FileSpreadsheet,
  Image as ImageIcon,
  Check,
  RotateCcw,
  Sliders,
  Eye,
  Upload,
  Receipt,
  FileText,
  Stamp,
  QrCode,
  ShieldCheck,
} from 'lucide-react';
import { InvoiceCustomization } from '../types';
import { DEFAULT_CUSTOMIZATION } from '../utils/storage';

interface InvoiceCustomizerProps {
  customization: InvoiceCustomization;
  setCustomization: React.Dispatch<React.SetStateAction<InvoiceCustomization>>;
  sellerLogo?: string;
  onUpdateSellerLogo?: (url: string) => void;
}

const COLOR_PRESETS = [
  { name: 'كحلي ملكي (افتراضي)', hex: '#1e3a8a' },
  { name: 'أخضر زمردي', hex: '#065f46' },
  { name: 'رمادي فاحم فاخر', hex: '#1e293b' },
  { name: 'عنابي دافئ', hex: '#831843' },
  { name: 'نيلي حديث', hex: '#3730a3' },
  { name: 'أسود موفر للحبر (أبيض وأسود)', hex: '#000000' },
];

const FONT_OPTIONS: Array<{ id: InvoiceCustomization['fontFamily']; label: string; desc: string }> = [
  { id: 'Cairo', label: 'خط كايرو (Cairo)', desc: 'خط عربي حديث وواضح جداً في الطباعة' },
  { id: 'Tajawal', label: 'خط تجوال (Tajawal)', desc: 'خط عصري رشيق وأنيق' },
  { id: 'Almarai', label: 'خط المراعي (Almarai)', desc: 'طابع مالي رسمي للمؤسسات' },
  { id: 'Amiri', label: 'خط أميري (Amiri)', desc: 'طابع تقليدي كلاسيكي راقٍ' },
];

export const InvoiceCustomizer: React.FC<InvoiceCustomizerProps> = ({
  customization,
  setCustomization,
  sellerLogo,
  onUpdateSellerLogo,
}) => {
  const logoInputRef = useRef<HTMLInputElement>(null);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        const url = event.target?.result as string;
        setCustomization((prev) => ({ ...prev, logoUrl: url, showLogo: true }));
        if (onUpdateSellerLogo) onUpdateSellerLogo(url);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleReset = () => {
    setCustomization(DEFAULT_CUSTOMIZATION);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">تخصيص مظهر الفاتورة قبل الطباعة</h3>
            <p className="text-xs text-slate-500">تحكم بالخط والشعار وحجم الورق والألوان</p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleReset}
          className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 font-semibold px-2 py-1 rounded hover:bg-slate-100"
          title="استعادة الإعدادات الافتراضية"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          إعادة تعيين
        </button>
      </div>

      {/* 1. Paper Format Layout (A4, A5, Thermal 80mm) */}
      <div>
        <label className="block text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
          <FileSpreadsheet className="w-4 h-4 text-blue-600" />
          تخطيط الفاتورة ومقاس الورق للطباعة:
        </label>
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => setCustomization((prev) => ({ ...prev, paperSize: 'a4', template: 'modern' }))}
            className={`p-3 rounded-xl border text-center transition-all ${
              customization.paperSize === 'a4'
                ? 'bg-blue-50 border-blue-600 text-blue-900 font-bold ring-2 ring-blue-500/20'
                : 'border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <FileText className="w-5 h-5 mx-auto mb-1 text-blue-600" />
            <span className="block text-xs font-bold">ورقة A4 كاملة</span>
            <span className="block text-[10px] text-slate-400">قياسي رسمي</span>
          </button>

          <button
            type="button"
            onClick={() => setCustomization((prev) => ({ ...prev, paperSize: 'a5', template: 'classic' }))}
            className={`p-3 rounded-xl border text-center transition-all ${
              customization.paperSize === 'a5'
                ? 'bg-blue-50 border-blue-600 text-blue-900 font-bold ring-2 ring-blue-500/20'
                : 'border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <FileText className="w-5 h-5 mx-auto mb-1 text-indigo-600" />
            <span className="block text-xs font-bold">ورقة A5 مضغوط</span>
            <span className="block text-[10px] text-slate-400">نصف صفحة</span>
          </button>

          <button
            type="button"
            onClick={() => setCustomization((prev) => ({ ...prev, paperSize: 'thermal_80mm', template: 'thermal_80mm' }))}
            className={`p-3 rounded-xl border text-center transition-all ${
              customization.paperSize === 'thermal_80mm'
                ? 'bg-blue-50 border-blue-600 text-blue-900 font-bold ring-2 ring-blue-500/20'
                : 'border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Receipt className="w-5 h-5 mx-auto mb-1 text-emerald-600" />
            <span className="block text-xs font-bold">رول حراري 80mm</span>
            <span className="block text-[10px] text-slate-400">طابعات POS وشحن</span>
          </button>
        </div>
      </div>

      {/* 2. Arabic Font Selection */}
      <div>
        <label className="block text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
          <Type className="w-4 h-4 text-blue-600" />
          اختيار خط الفاتورة العربي:
        </label>
        <div className="grid grid-cols-2 gap-2">
          {FONT_OPTIONS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setCustomization((prev) => ({ ...prev, fontFamily: f.id }))}
              style={{ fontFamily: f.id }}
              className={`p-2.5 rounded-xl border text-right transition-all flex items-center justify-between ${
                customization.fontFamily === f.id
                  ? 'border-blue-600 bg-blue-50/60 text-blue-950 font-bold ring-1 ring-blue-500'
                  : 'border-slate-200 hover:bg-slate-50 text-slate-800'
              }`}
            >
              <div>
                <span className="block text-xs font-bold">{f.label}</span>
                <span className="block text-[10px] text-slate-500">{f.desc}</span>
              </div>
              {customization.fontFamily === f.id && <Check className="w-4 h-4 text-blue-600" />}
            </button>
          ))}
        </div>
      </div>

      {/* 3. Company Logo Upload & Settings */}
      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <ImageIcon className="w-4 h-4 text-blue-600" />
            شعار الشركة / المتجر (Logo):
          </label>
          <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
            <input
              type="checkbox"
              checked={customization.showLogo}
              onChange={(e) =>
                setCustomization((prev) => ({ ...prev, showLogo: e.target.checked }))
              }
              className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
            />
            <span>إظهار الشعار في الفاتورة</span>
          </label>
        </div>

        {customization.showLogo && (
          <div className="flex items-center gap-4 pt-1">
            <div className="w-14 h-14 rounded-xl bg-white border border-slate-300 flex items-center justify-center overflow-hidden shrink-0 shadow-xs">
              {customization.logoUrl || sellerLogo ? (
                <img
                  src={customization.logoUrl || sellerLogo}
                  alt="Company Logo"
                  className="max-h-full max-w-full object-contain"
                />
              ) : (
                <ImageIcon className="w-6 h-6 text-slate-300" />
              )}
            </div>

            <div className="flex-1 space-y-1.5">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => logoInputRef.current?.click()}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-bold text-slate-800 flex items-center gap-1.5 shadow-xs"
                >
                  <Upload className="w-3.5 h-3.5 text-blue-600" />
                  رفع لوجو جديد من جهازك
                </button>
                <input
                  ref={logoInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </div>

              {/* Logo size options */}
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span>الحجم:</span>
                {(['small', 'medium', 'large'] as const).map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => setCustomization((prev) => ({ ...prev, logoSize: sz }))}
                    className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      customization.logoSize === sz
                        ? 'bg-blue-600 text-white'
                        : 'bg-white border border-slate-200 text-slate-700'
                    }`}
                  >
                    {sz === 'small' ? 'صغير' : sz === 'medium' ? 'متوسط' : 'كبير'}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 4. Color Palette */}
      <div>
        <label className="block text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
          <Palette className="w-4 h-4 text-blue-600" />
          لون الفاتورة والعناوين الرئيسية:
        </label>
        <div className="flex flex-wrap gap-2">
          {COLOR_PRESETS.map((color) => (
            <button
              key={color.hex}
              type="button"
              onClick={() => setCustomization((prev) => ({ ...prev, primaryColor: color.hex }))}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                customization.primaryColor === color.hex
                  ? 'border-slate-800 bg-slate-100 ring-2 ring-blue-500/30'
                  : 'border-slate-200 bg-white hover:bg-slate-50'
              }`}
            >
              <span
                className="w-3.5 h-3.5 rounded-full border border-black/10 shrink-0"
                style={{ backgroundColor: color.hex }}
              />
              <span>{color.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 5. Header Title & Content Toggles */}
      <div className="space-y-3 pt-2 border-t border-slate-100">
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            عنوان الفاتورة المطبوعة:
          </label>
          <input
            type="text"
            value={customization.headerTitle}
            onChange={(e) =>
              setCustomization((prev) => ({ ...prev, headerTitle: e.target.value }))
            }
            className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold focus:ring-1 focus:ring-blue-500 outline-none"
            placeholder="فاتورة مبيعات وتسليم"
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2">
          <label className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200 text-xs font-bold text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={customization.showStamp}
              onChange={(e) =>
                setCustomization((prev) => ({ ...prev, showStamp: e.target.checked }))
              }
              className="w-3.5 h-3.5 text-blue-600 rounded"
            />
            <Stamp className="w-3.5 h-3.5 text-slate-500" />
            <span>ختم وتوقيع المتجر</span>
          </label>

          <label className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200 text-xs font-bold text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={customization.showQrCode}
              onChange={(e) =>
                setCustomization((prev) => ({ ...prev, showQrCode: e.target.checked }))
              }
              className="w-3.5 h-3.5 text-blue-600 rounded"
            />
            <QrCode className="w-3.5 h-3.5 text-slate-500" />
            <span>رمز QR للتحقق</span>
          </label>

          <label className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200 text-xs font-bold text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={customization.showBarcode}
              onChange={(e) =>
                setCustomization((prev) => ({ ...prev, showBarcode: e.target.checked }))
              }
              className="w-3.5 h-3.5 text-blue-600 rounded"
            />
            <span>باركود الشحنة</span>
          </label>

          <label className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200 text-xs font-bold text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={customization.showTafqeet}
              onChange={(e) =>
                setCustomization((prev) => ({ ...prev, showTafqeet: e.target.checked }))
              }
              className="w-3.5 h-3.5 text-blue-600 rounded"
            />
            <span>تفقيط المبلغ كتابة</span>
          </label>

          <label className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200 text-xs font-bold text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={customization.showTerms}
              onChange={(e) =>
                setCustomization((prev) => ({ ...prev, showTerms: e.target.checked }))
              }
              className="w-3.5 h-3.5 text-blue-600 rounded"
            />
            <ShieldCheck className="w-3.5 h-3.5 text-slate-500" />
            <span>سياسة الاسترجاع</span>
          </label>

          <label className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200 text-xs font-bold text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={customization.showDeliveryNotes}
              onChange={(e) =>
                setCustomization((prev) => ({ ...prev, showDeliveryNotes: e.target.checked }))
              }
              className="w-3.5 h-3.5 text-blue-600 rounded"
            />
            <span>ملاحظات التوصيل</span>
          </label>
        </div>
      </div>
    </div>
  );
};
