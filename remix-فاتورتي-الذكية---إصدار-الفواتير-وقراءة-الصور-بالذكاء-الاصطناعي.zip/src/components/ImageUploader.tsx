import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  Camera,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Loader2,
  FileImage,
  RefreshCw,
  X,
  Clipboard,
} from 'lucide-react';
import { SAMPLE_IMAGES, SampleImage } from '../utils/sampleImages';
import { InvoiceItem } from '../types';

interface ExtractedData {
  customerName?: string;
  customerPhone?: string;
  customerAddress?: string;
  customerCity?: string;
  invoiceNumber?: string;
  date?: string;
  shippingCompany?: string;
  shippingCost?: number;
  notes?: string;
  items?: Array<{
    name: string;
    quantity: number;
    price: number;
    total: number;
  }>;
}

interface ImageUploaderProps {
  onDataExtracted: (data: {
    customerName: string;
    customerPhone: string;
    customerAddress: string;
    customerCity: string;
    shippingCompany: string;
    shippingCost: number;
    notes: string;
    invoiceNumber?: string;
    date?: string;
    items: InvoiceItem[];
  }) => void;
  onClose?: () => void;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({
  onDataExtracted,
  onClose,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState<string>('image/jpeg');
  const [fileName, setFileName] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [extractedResult, setExtractedResult] = useState<ExtractedData | null>(null);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('يرجى اختيار ملف صورة صالح (JPG, PNG, WEBP)');
      return;
    }

    setFileName(file.name);
    setImageMime(file.type);
    setError(null);
    setExtractedResult(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setSelectedImage(result);
      processImageWithAI(result, file.type);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    if (e.clipboardData.files && e.clipboardData.files[0]) {
      handleFileChange(e.clipboardData.files[0]);
    } else {
      const items = e.clipboardData.items;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            handleFileChange(blob);
            break;
          }
        }
      }
    }
  };

  const handleSelectSample = (sample: SampleImage) => {
    setSelectedImage(sample.dataUrl);
    setFileName(sample.title);
    setImageMime('image/svg+xml');
    setError(null);
    setExtractedResult(null);
    processImageWithAI(sample.dataUrl, 'image/svg+xml');
  };

  const processImageWithAI = async (imageData: string, mime: string) => {
    setIsProcessing(true);
    setError(null);

    try {
      const res = await fetch('/api/extract-invoice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: imageData,
          mimeType: mime,
        }),
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'فشلت معالجة الصورة، يرجى المحاولة مجدداً');
      }

      setExtractedResult(json.data);
    } catch (err: any) {
      console.error('Extraction error:', err);
      setError(err?.message || 'حدث خطأ أثناء التواصل مع نموذج الذكاء الاصطناعي');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApplyData = () => {
    if (!extractedResult) return;

    const formattedItems: InvoiceItem[] = (extractedResult.items || []).map((item, idx) => ({
      id: 'item-ai-' + Date.now() + '-' + idx,
      name: item.name || 'منتج غير محدد',
      quantity: Number(item.quantity) || 1,
      price: Number(item.price) || 0,
      total: Number(item.total) || (Number(item.quantity) || 1) * (Number(item.price) || 0),
    }));

    onDataExtracted({
      customerName: extractedResult.customerName || '',
      customerPhone: extractedResult.customerPhone || '',
      customerAddress: extractedResult.customerAddress || '',
      customerCity: extractedResult.customerCity || '',
      shippingCompany: extractedResult.shippingCompany || '',
      shippingCost: Number(extractedResult.shippingCost) || 0,
      notes: extractedResult.notes || '',
      invoiceNumber: extractedResult.invoiceNumber,
      date: extractedResult.date,
      items:
        formattedItems.length > 0
          ? formattedItems
          : [{ id: 'item-1', name: 'منتج جديد', quantity: 1, price: 0, total: 0 }],
    });

    if (onClose) onClose();
  };

  return (
    <div
      onPaste={handlePaste}
      tabIndex={0}
      className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden focus:outline-none focus:ring-2 focus:ring-blue-500/20"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-300">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base sm:text-lg flex items-center gap-2">
              استخراج بيانات الفاتورة بالذكاء الاصطناعي
            </h3>
            <p className="text-xs text-blue-200">
              ارفع صورة بوليصة الشحن، محادثة الواتساب، أو الفاتورة الورقية لاستخراج البيانات تلقائياً
            </p>
          </div>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="text-slate-300 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      <div className="p-6">
        {/* Drop zone / Upload area */}
        {!selectedImage ? (
          <div>
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragOver(true);
              }}
              onDragLeave={() => setIsDragOver(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
                isDragOver
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-slate-300 hover:border-blue-400 hover:bg-slate-50'
              }`}
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shadow-inner">
                <UploadCloud className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-slate-800 text-base mb-1">
                اضغط لاختيار صورة الفاتورة أو اسحبها وأفلتها هنا
              </h4>
              <p className="text-sm text-slate-500 mb-4">
                يدعم صور محادثات الواتساب، بوالص الشحن (بوسطة، أرامكس، سمسا، ...)، والفواتير الورقية
              </p>

              <div className="flex flex-wrap items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    fileInputRef.current?.click();
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold flex items-center gap-2 shadow-xs"
                >
                  <FileImage className="w-4 h-4" />
                  اختيار ملف من الجهاز
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    cameraInputRef.current?.click();
                  }}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-sm font-semibold flex items-center gap-2 shadow-xs"
                >
                  <Camera className="w-4 h-4" />
                  التقاط بالكاميرا
                </button>

                <span className="text-xs text-slate-400 flex items-center gap-1 bg-slate-100 px-3 py-2 rounded-lg">
                  <Clipboard className="w-3.5 h-3.5" />
                  أو الصق بـ Ctrl + V
                </span>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileChange(e.target.files[0]);
                  }
                }}
              />
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileChange(e.target.files[0]);
                  }
                }}
              />
            </div>

            {/* Quick Sample Demos */}
            <div className="mt-6 pt-5 border-t border-slate-200">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  جرّب فوراً بنموذج جاهز بنقرة واحدة:
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SAMPLE_IMAGES.map((sample) => (
                  <button
                    key={sample.id}
                    type="button"
                    onClick={() => handleSelectSample(sample)}
                    className="flex items-center gap-3 p-3 text-right bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-xl transition-all group"
                  >
                    <div className="w-12 h-12 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-blue-600 shrink-0 shadow-xs">
                      <FileImage className="w-6 h-6 text-slate-400 group-hover:text-blue-600 transition-colors" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-slate-900 group-hover:text-blue-700">
                        {sample.title}
                      </p>
                      <p className="text-xs text-slate-500 truncate">{sample.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* Processing & Result View */
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              {/* Image Preview with scanner line */}
              <div className="md:col-span-5 bg-slate-100 rounded-xl p-3 border border-slate-200 flex flex-col items-center justify-center relative overflow-hidden min-h-[300px]">
                <img
                  src={selectedImage}
                  alt="Invoice source"
                  className="max-h-[360px] max-w-full rounded-lg object-contain shadow-xs"
                />

                {/* Laser scan animation when processing */}
                {isProcessing && (
                  <div className="absolute inset-0 bg-blue-900/10 backdrop-blur-[1px] flex flex-col items-center justify-center">
                    <div className="absolute w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#22d3ee] animate-pulse top-1/2" />
                    <div className="bg-slate-900/90 text-white px-4 py-2.5 rounded-xl shadow-lg border border-cyan-500/40 flex items-center gap-2.5 text-sm font-bold">
                      <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                      جاري فحص واستخراج بيانات الفاتورة...
                    </div>
                  </div>
                )}

                <div className="mt-3 flex items-center justify-between w-full text-xs text-slate-600 px-1">
                  <span className="truncate max-w-[200px]">{fileName}</span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedImage(null);
                      setExtractedResult(null);
                      setError(null);
                    }}
                    className="text-red-600 hover:text-red-700 font-semibold flex items-center gap-1 hover:underline"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    تغيير الصورة
                  </button>
                </div>
              </div>

              {/* Extraction Details */}
              <div className="md:col-span-7 flex flex-col">
                {isProcessing ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 bg-slate-50 rounded-xl border border-dashed border-slate-300">
                    <div className="w-14 h-14 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mb-4 animate-bounce">
                      <Sparkles className="w-7 h-7" />
                    </div>
                    <h4 className="text-base font-bold text-slate-900 mb-1">
                      الذكاء الاصطناعي يحلل صورة الفاتورة
                    </h4>
                    <p className="text-sm text-slate-500 max-w-sm">
                      يتم التعرف الآن على اسم العميل، رقم الهاتف، العنوان، المنتجات وسعرها، وتكلفة وشركة الشحن بدقة...
                    </p>
                  </div>
                ) : error ? (
                  <div className="p-5 bg-red-50 border border-red-200 rounded-xl text-red-800">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                      <div>
                        <h5 className="font-bold text-sm mb-1">تعذر استخراج البيانات</h5>
                        <p className="text-xs text-red-700 mb-3">{error}</p>
                        <button
                          type="button"
                          onClick={() => processImageWithAI(selectedImage, imageMime)}
                          className="px-3 py-1.5 bg-red-600 text-white rounded-lg text-xs font-semibold hover:bg-red-700 flex items-center gap-1.5"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          إعادة المحاولة
                        </button>
                      </div>
                    </div>
                  </div>
                ) : extractedResult ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                      <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        تم استخراج البيانات بنجاح
                      </div>
                      <span className="text-xs text-slate-500">
                        {extractedResult.items?.length || 0} منتجات مكتشفة
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                        <span className="text-slate-500 block">اسم العميل:</span>
                        <span className="font-bold text-slate-900 text-sm">
                          {extractedResult.customerName || 'غير محدد'}
                        </span>
                      </div>

                      <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                        <span className="text-slate-500 block">رقم الهاتف:</span>
                        <span className="font-bold text-slate-900 text-sm" dir="ltr">
                          {extractedResult.customerPhone || 'غير محدد'}
                        </span>
                      </div>

                      <div className="col-span-2 p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                        <span className="text-slate-500 block">العنوان والمحافظة:</span>
                        <span className="font-medium text-slate-900 text-xs">
                          {extractedResult.customerAddress || ''}{' '}
                          {extractedResult.customerCity ? `(${extractedResult.customerCity})` : ''}
                        </span>
                      </div>

                      <div className="p-2.5 bg-blue-50/70 rounded-lg border border-blue-200">
                        <span className="text-blue-700 block">شركة الشحن:</span>
                        <span className="font-bold text-blue-950 text-sm">
                          {extractedResult.shippingCompany || 'شحن عادي'}
                        </span>
                      </div>

                      <div className="p-2.5 bg-blue-50/70 rounded-lg border border-blue-200">
                        <span className="text-blue-700 block">سعر الشحن:</span>
                        <span className="font-bold text-blue-950 text-sm">
                          {extractedResult.shippingCost || 0} ج.م
                        </span>
                      </div>
                    </div>

                    {/* Products Preview */}
                    <div>
                      <span className="text-xs font-bold text-slate-600 block mb-2">
                        المنتجات والأسعار المستخرجة:
                      </span>
                      <div className="max-h-36 overflow-y-auto rounded-lg border border-slate-200 divide-y divide-slate-100 text-xs">
                        {extractedResult.items && extractedResult.items.length > 0 ? (
                          extractedResult.items.map((item, idx) => (
                            <div key={idx} className="p-2 flex items-center justify-between bg-white hover:bg-slate-50">
                              <span className="font-medium text-slate-800">{item.name}</span>
                              <div className="flex items-center gap-3">
                                <span className="text-slate-500">الكمية: {item.quantity}</span>
                                <span className="font-bold text-slate-900">{item.price} ج.م</span>
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="p-2 text-slate-400 text-center">لا توجد منتجات مسجلة</div>
                        )}
                      </div>
                    </div>

                    {/* Action button */}
                    <div className="pt-2 flex items-center gap-3">
                      <button
                        type="button"
                        onClick={handleApplyData}
                        className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-sm shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all"
                      >
                        <CheckCircle2 className="w-5 h-5" />
                        نقل البيانات للفاتورة والبدء في التعديل
                      </button>
                    </div>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
