import React, { useState } from 'react';
import {
  Truck,
  Plus,
  Star,
  Phone,
  DollarSign,
  Edit2,
  Trash2,
  Search,
  Check,
  X,
  AlertCircle,
  ShieldAlert,
} from 'lucide-react';
import { ShippingCompany } from '../types';

interface ShippingCompaniesManagerProps {
  shippingCompanies: ShippingCompany[];
  onSaveCompany: (company: ShippingCompany) => void;
  onTogglePin: (id: string) => void;
  onDeleteCompany: (id: string) => void;
}

export const ShippingCompaniesManager: React.FC<ShippingCompaniesManagerProps> = ({
  shippingCompanies,
  onSaveCompany,
  onTogglePin,
  onDeleteCompany,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingCompany, setEditingCompany] = useState<ShippingCompany | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [defaultCost, setDefaultCost] = useState<number>(50);
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [isPinned, setIsPinned] = useState<boolean>(true);

  const openModal = (company?: ShippingCompany) => {
    if (company) {
      setEditingCompany(company);
      setName(company.name);
      setDefaultCost(company.defaultCost);
      setPhone(company.phone || '');
      setNotes(company.notes || '');
      setIsPinned(company.isPinned);
    } else {
      setEditingCompany(null);
      setName('');
      setDefaultCost(50);
      setPhone('');
      setNotes('');
      setIsPinned(true);
    }
    setShowModal(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const company: ShippingCompany = {
      id: editingCompany ? editingCompany.id : 'ship-' + Date.now(),
      name: name.trim(),
      defaultCost: Number(defaultCost) || 0,
      phone: phone.trim() || undefined,
      notes: notes.trim() || undefined,
      isPinned,
      isDefault: editingCompany ? editingCompany.isDefault : false,
    };

    onSaveCompany(company);
    setShowModal(false);
  };

  const filteredCompanies = shippingCompanies.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.notes && c.notes.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const pinnedCount = shippingCompanies.filter((c) => c.isPinned).length;

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-800 via-indigo-800 to-slate-900 rounded-2xl p-6 text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-amber-400/20 text-amber-300 text-xs px-2.5 py-0.5 rounded-full font-bold border border-amber-400/30 flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-amber-300" />
              تثبيت الشركات في الفاتورة ({pinnedCount})
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black">إدارة وتثبيت شركات الشحن</h2>
          <p className="text-xs sm:text-sm text-blue-100 mt-1">
            حدد الشركات المثبتة لتظهر تلقائياً في شاشة الفاتورة مع سعر الشحن المعتمد لكل شركة
          </p>
        </div>

        <button
          type="button"
          onClick={() => openModal()}
          className="px-5 py-3 bg-white text-blue-900 hover:bg-blue-50 rounded-xl font-bold text-sm shadow-md flex items-center gap-2 transition-all hover:scale-[1.02] shrink-0"
        >
          <Plus className="w-4 h-4 text-blue-700" />
          إضافة شركة شحن جديدة
        </button>
      </div>

      {/* Search and Summary */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:max-w-md">
          <input
            type="text"
            placeholder="بحث باسم شركة الشحن أو الملاحظات..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 pr-10 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3 pointer-events-none" />
        </div>

        <div className="text-xs text-slate-500 flex items-center gap-2">
          <span>الشركات المثبتة بالواجهة السريعة:</span>
          <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200">
            {pinnedCount} من أصل {shippingCompanies.length}
          </span>
        </div>
      </div>

      {/* Companies Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCompanies.map((company) => (
          <div
            key={company.id}
            className={`bg-white rounded-2xl border transition-all p-5 shadow-xs flex flex-col justify-between ${
              company.isPinned
                ? 'border-blue-400 ring-1 ring-blue-500/20 bg-gradient-to-b from-blue-50/20 to-white'
                : 'border-slate-200 hover:border-slate-300'
            }`}
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                    <Truck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-base">{company.name}</h3>
                    {company.phone && (
                      <span className="text-xs text-slate-500 flex items-center gap-1 mt-0.5" dir="ltr">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {company.phone}
                      </span>
                    )}
                  </div>
                </div>

                {/* Pin Toggle Button */}
                <button
                  type="button"
                  onClick={() => onTogglePin(company.id)}
                  className={`p-2 rounded-xl transition-colors ${
                    company.isPinned
                      ? 'bg-amber-100 text-amber-600 hover:bg-amber-200'
                      : 'bg-slate-100 text-slate-400 hover:text-amber-500 hover:bg-amber-50'
                  }`}
                  title={company.isPinned ? 'إلغاء التثبيت من الواجهة' : 'تثبيت في واجهة الفاتورة السريعة'}
                >
                  <Star className={`w-4 h-4 ${company.isPinned ? 'fill-amber-500' : ''}`} />
                </button>
              </div>

              {/* Default Cost Badge */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 mb-3 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-600">سعر الشحن الافتراضي:</span>
                <span className="text-base font-black text-blue-900">
                  {company.defaultCost} <span className="text-xs font-normal text-slate-500">ج.م</span>
                </span>
              </div>

              {company.notes && (
                <p className="text-xs text-slate-500 line-clamp-2 mb-4">{company.notes}</p>
              )}
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-400">
                {company.isPinned ? '⭐ مثبت في الفاتورة' : 'غير مثبت'}
              </span>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => openModal(company)}
                  className="p-1.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                  title="تعديل"
                >
                  <Edit2 className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (confirm(`هل أنت متأكد من حذف شركة الشحن "${company.name}"؟`)) {
                      onDeleteCompany(company.id);
                    }
                  }}
                  className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  title="حذف"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Company Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
              <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2">
                <Truck className="w-5 h-5 text-blue-600" />
                {editingCompany ? 'تعديل شركة الشحن' : 'إضافة شركة شحن جديدة'}
              </h3>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم شركة الشحن <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="مثال: بوسطة، أرامكس، سمسا، مندوب إكسبريس..."
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  تكلفة الشحن الافتراضية (ج.م) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  min="0"
                  value={defaultCost}
                  onChange={(e) => setDefaultCost(parseFloat(e.target.value) || 0)}
                  required
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  رقم هاتف أو خدمة عملاء الشركة (اختياري)
                </label>
                <input
                  type="text"
                  placeholder="مثال: 19035 أو رقم المندوب"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ملاحظات أو مناطق التغطية (اختياري)
                </label>
                <textarea
                  rows={2}
                  placeholder="مثال: توصيل سريع خلال 24 ساعة، شحن محافظات الصعيد..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <input
                    type="checkbox"
                    checked={isPinned}
                    onChange={(e) => setIsPinned(e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">
                      تثبيت هذه الشركة في الواجهة السريعة للفاتورة ⭐
                    </span>
                    <span className="text-[11px] text-slate-500 block">
                      ستظهر كزر اختصار سريع في نموذج الفاتورة للاختيار الفوري
                    </span>
                  </div>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-sm"
                >
                  حفظ شركة الشحن
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
