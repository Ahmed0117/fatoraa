import React from 'react';
import {
  FileText,
  Printer,
  Users,
  Truck,
  Building2,
  Archive,
  Sparkles,
  Layers,
} from 'lucide-react';

export type ActiveTab =
  | 'builder'
  | 'print'
  | 'customers'
  | 'shipping'
  | 'seller'
  | 'archive';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  invoicesCount: number;
  customersCount: number;
  pinnedShippingCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  invoicesCount,
  customersCount,
  pinnedShippingCount,
}) => {
  const navItems = [
    {
      id: 'builder' as ActiveTab,
      label: 'إصدار الفاتورة والمطابقة',
      icon: FileText,
      badge: 'الرئيسية',
    },
    {
      id: 'print' as ActiveTab,
      label: 'معاينة وتخصيص الطباعة',
      icon: Printer,
      badge: null,
    },
    {
      id: 'customers' as ActiveTab,
      label: 'تتبع وسجل العملاء',
      icon: Users,
      badge: customersCount > 0 ? customersCount.toString() : null,
    },
    {
      id: 'shipping' as ActiveTab,
      label: 'شركات الشحن والتثبيت',
      icon: Truck,
      badge: pinnedShippingCount > 0 ? `⭐ ${pinnedShippingCount}` : null,
    },
    {
      id: 'archive' as ActiveTab,
      label: 'أرشيف الفواتير',
      icon: Archive,
      badge: invoicesCount > 0 ? invoicesCount.toString() : null,
    },
    {
      id: 'seller' as ActiveTab,
      label: 'بيانات المتجر والشركات',
      icon: Building2,
      badge: null,
    },
  ];

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & App Brand */}
          <div className="flex items-center space-x-reverse space-x-3 cursor-pointer" onClick={() => setActiveTab('builder')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-slate-900 tracking-tight">فاتورتي الذكية</h1>
                <span className="text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-blue-600" />
                  قراءة الصور بالذكاء الاصطناعي
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">إصدار الفواتير • إدارة الشحن • تتبع العملاء والمبيعات</p>
            </div>
          </div>

          {/* Quick Actions / Date */}
          <div className="hidden lg:flex items-center gap-3 text-xs text-slate-500">
            <span className="flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
              <Layers className="w-3.5 h-3.5 text-slate-600" />
              جاهز للطباعة A4 ورول حراري 80mm
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-reverse space-x-1 sm:space-x-reverse sm:space-x-2 overflow-x-auto py-2 border-t border-slate-100 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all duration-150 ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm font-bold shadow-blue-500/25'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`text-[11px] px-1.5 py-0.2 rounded-full font-semibold ${
                      isActive
                        ? 'bg-blue-700/80 text-blue-100'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
