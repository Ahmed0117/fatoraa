import React, { useState, useEffect } from 'react';
import {
  Printer,
  Edit3,
  Sparkles,
  ArrowRight,
  Download,
  Share2,
  CheckCircle,
} from 'lucide-react';
import {
  Customer,
  Invoice,
  InvoiceCustomization,
  InvoiceItem,
  InvoiceStatus,
  SellerCompany,
  ShippingCompany,
} from './types';
import {
  getCustomers,
  saveCustomer,
  deleteCustomer,
  getInvoices,
  saveInvoice,
  deleteInvoice,
  getShippingCompanies,
  saveShippingCompany,
  togglePinShippingCompany,
  deleteShippingCompany,
  getSellerCompanies,
  saveSellerCompany,
  getDefaultSellerCompany,
  getCustomization,
  saveCustomization,
} from './utils/storage';
import { Navbar, ActiveTab } from './components/Navbar';
import { ImageUploader } from './components/ImageUploader';
import { InvoiceEditor } from './components/InvoiceEditor';
import { InvoiceCustomizer } from './components/InvoiceCustomizer';
import { PrintableInvoice } from './components/PrintableInvoice';
import { CustomerManager } from './components/CustomerManager';
import { ShippingCompaniesManager } from './components/ShippingCompaniesManager';
import { CompanyProfileManager } from './components/CompanyProfileManager';
import { InvoiceArchive } from './components/InvoiceArchive';

export default function App() {
  // Global States
  const [activeTab, setActiveTab] = useState<ActiveTab>('builder');
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [shippingCompanies, setShippingCompanies] = useState<ShippingCompany[]>([]);
  const [sellerCompanies, setSellerCompanies] = useState<SellerCompany[]>([]);
  const [customization, setCustomization] = useState<InvoiceCustomization>(getCustomization());

  // AI Scanner Modal
  const [showAiScanner, setShowAiScanner] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Active Invoice State
  const generateNewInvoiceNumber = () => {
    const timestamp = Date.now().toString().slice(-4);
    const random = Math.floor(100 + Math.random() * 900);
    return `INV-${new Date().getFullYear()}-${timestamp}${random}`;
  };

  const createBlankInvoice = (sellerId?: string): Invoice => ({
    id: 'inv-' + Date.now(),
    invoiceNumber: generateNewInvoiceNumber(),
    date: new Date().toISOString().slice(0, 10),
    customerName: '',
    customerPhone: '',
    customerAddress: '',
    customerCity: '',
    items: [
      { id: 'item-1', name: '', quantity: 1, price: 0, total: 0 },
    ],
    shippingCompany: 'بوسطة (Bosta)',
    shippingCost: 55,
    discount: 0,
    taxRate: 0,
    subtotal: 0,
    total: 55,
    paymentMethod: 'cash_on_delivery',
    status: 'draft',
    sellerCompanyId: sellerId,
    createdAt: new Date().toISOString(),
  });

  const [currentInvoice, setCurrentInvoice] = useState<Invoice>(() => createBlankInvoice());

  // Initial Load from LocalStorage
  useEffect(() => {
    const loadedCustomers = getCustomers();
    const loadedInvoices = getInvoices();
    const loadedShipping = getShippingCompanies();
    const loadedSellers = getSellerCompanies();
    const loadedCustomization = getCustomization();

    setCustomers(loadedCustomers);
    setInvoices(loadedInvoices);
    setShippingCompanies(loadedShipping);
    setSellerCompanies(loadedSellers);
    setCustomization(loadedCustomization);

    // Set default seller in current invoice if not set
    const defaultSeller = loadedSellers.find((s) => s.isDefault) || loadedSellers[0];
    if (defaultSeller) {
      setCurrentInvoice((prev) => ({
        ...prev,
        sellerCompanyId: defaultSeller.id,
      }));
    }
  }, []);

  // Save customization changes automatically
  useEffect(() => {
    saveCustomization(customization);
  }, [customization]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Handlers for Invoices
  const handleSaveInvoice = () => {
    if (!currentInvoice.customerName.trim()) {
      alert('يرجى كتابة اسم العميل على الأقل لحفظ الفاتورة');
      return;
    }

    const updatedInvoices = saveInvoice(currentInvoice);
    setInvoices(updatedInvoices);
    setCustomers(getCustomers()); // reload customers since saveInvoice updates customer info
    showToast(`تم حفظ الفاتورة #${currentInvoice.invoiceNumber} بنجاح في الأرشيف!`);
  };

  const handleResetInvoice = () => {
    const defaultSeller = sellerCompanies.find((s) => s.isDefault) || sellerCompanies[0];
    setCurrentInvoice(createBlankInvoice(defaultSeller?.id));
    showToast('تم تجهيز فاتورة جديدة فارغة');
  };

  // Handlers for AI Extracted Data
  const handleDataExtracted = (data: {
    customerName: string;
    customerPhone: string;
    customerAddress: string;
    customerCity: string;
    shippingCompany: string;
    shippingCost: number;
    notes: string;
    invoiceNumber?: string;
    date?: string;
    items: InvoiceItem[];
  }) => {
    setCurrentInvoice((prev) => {
      // Find matching shipping company if available to pull default rate
      const matchedCompany = shippingCompanies.find(
        (c) =>
          data.shippingCompany &&
          c.name.toLowerCase().includes(data.shippingCompany.toLowerCase())
      );

      const finalShippingCompany =
        data.shippingCompany || matchedCompany?.name || prev.shippingCompany || 'شحن خاص';
      const finalShippingCost =
        data.shippingCost > 0
          ? data.shippingCost
          : matchedCompany?.defaultCost || prev.shippingCost || 50;

      const subtotal = data.items.reduce(
        (acc, item) => acc + (Number(item.quantity) || 0) * (Number(item.price) || 0),
        0
      );

      return {
        ...prev,
        customerName: data.customerName || prev.customerName,
        customerPhone: data.customerPhone || prev.customerPhone,
        customerAddress: data.customerAddress || prev.customerAddress,
        customerCity: data.customerCity || prev.customerCity,
        shippingCompany: finalShippingCompany,
        shippingCost: finalShippingCost,
        notes: data.notes || prev.notes,
        invoiceNumber: data.invoiceNumber || prev.invoiceNumber,
        date: data.date || prev.date,
        items: data.items,
        subtotal,
        total: subtotal + finalShippingCost,
        extractedFromImage: true,
      };
    });

    setShowAiScanner(false);
    setActiveTab('builder');
    showToast('تم استخراج وتطبيق بيانات الفاتورة بنجاح!');
  };

  // Handlers for Shipping Companies
  const handleSaveShippingCompany = (company: ShippingCompany) => {
    const updated = saveShippingCompany(company);
    setShippingCompanies(updated);
    showToast(`تم حفظ شركة الشحن "${company.name}"`);
  };

  const handleQuickAddShipping = (name: string, cost: number) => {
    const newComp: ShippingCompany = {
      id: 'ship-' + Date.now(),
      name,
      defaultCost: cost,
      isPinned: true,
    };
    const updated = saveShippingCompany(newComp);
    setShippingCompanies(updated);
    showToast(`تمت إضافة وتثبيت شركة الشحن "${name}"`);
  };

  const handleTogglePinShipping = (id: string) => {
    const updated = togglePinShippingCompany(id);
    setShippingCompanies(updated);
  };

  const handleDeleteShippingCompany = (id: string) => {
    const updated = deleteShippingCompany(id);
    setShippingCompanies(updated);
    showToast('تم حذف شركة الشحن');
  };

  // Handlers for Customers CRM
  const handleSaveCustomer = (customer: Customer) => {
    const updated = saveCustomer(customer);
    setCustomers(updated);
    showToast(`تم حفظ بيانات العميل "${customer.name}"`);
  };

  const handleDeleteCustomer = (id: string) => {
    const updated = deleteCustomer(id);
    setCustomers(updated);
    showToast('تم حذف العميل');
  };

  const handleCreateInvoiceForCustomer = (customer: Customer) => {
    const defaultSeller = sellerCompanies.find((s) => s.isDefault) || sellerCompanies[0];
    const newInv: Invoice = {
      ...createBlankInvoice(defaultSeller?.id),
      customerId: customer.id,
      customerName: customer.name,
      customerPhone: customer.phone,
      customerAddress: customer.address,
      customerCity: customer.city,
    };
    setCurrentInvoice(newInv);
    setActiveTab('builder');
    showToast(`تم إنشاء فاتورة جديدة مجهزة للعميل "${customer.name}"`);
  };

  // Handlers for Seller Profile
  const handleSaveSellerCompany = (company: SellerCompany) => {
    const updated = saveSellerCompany(company);
    setSellerCompanies(updated);
    showToast(`تم حفظ بيانات المتجر "${company.name}"`);
  };

  const handleSetDefaultSellerCompany = (id: string) => {
    const updated = sellerCompanies.map((c) => ({
      ...c,
      isDefault: c.id === id,
    }));
    updated.forEach((c) => saveSellerCompany(c));
    setSellerCompanies(updated);
    showToast('تم تعيين المتجر كافتراضي للفواتير');
  };

  // Archive Actions
  const handleSelectInvoiceFromArchive = (inv: Invoice, action: 'print' | 'edit') => {
    setCurrentInvoice(inv);
    if (action === 'print') {
      setActiveTab('print');
    } else {
      setActiveTab('builder');
    }
  };

  const handleDuplicateInvoice = (inv: Invoice) => {
    const duplicated: Invoice = {
      ...inv,
      id: 'inv-' + Date.now(),
      invoiceNumber: generateNewInvoiceNumber(),
      date: new Date().toISOString().slice(0, 10),
      status: 'draft',
      createdAt: new Date().toISOString(),
    };
    setCurrentInvoice(duplicated);
    setActiveTab('builder');
    showToast(`تم نسخ الفاتورة برقم جديد #${duplicated.invoiceNumber}`);
  };

  const handleDeleteInvoice = (id: string) => {
    const updated = deleteInvoice(id);
    setInvoices(updated);
    showToast('تم حذف الفاتورة من الأرشيف');
  };

  const handleStatusChange = (id: string, newStatus: InvoiceStatus) => {
    const inv = invoices.find((i) => i.id === id);
    if (inv) {
      const updated = { ...inv, status: newStatus };
      const list = saveInvoice(updated);
      setInvoices(list);
      if (currentInvoice.id === id) {
        setCurrentInvoice(updated);
      }
      showToast('تم تحديث حالة الفاتورة');
    }
  };

  // Active seller company for print
  const activeSeller =
    sellerCompanies.find((s) => s.id === currentInvoice.sellerCompanyId) ||
    sellerCompanies.find((s) => s.isDefault) ||
    sellerCompanies[0] || {
      id: 'default',
      name: 'متجري',
      phone: '',
      address: '',
      currency: 'ج.م',
      isDefault: true,
    };

  const pinnedShippingCount = shippingCompanies.filter((c) => c.isPinned).length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-['Cairo',sans-serif]">
      {/* Navbar with tab switching */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        invoicesCount={invoices.length}
        customersCount={customers.length}
        pinnedShippingCount={pinnedShippingCount}
      />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 text-sm font-bold border border-slate-700 animate-slide-up">
          <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Content Areas */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {/* TAB 1: Invoice Builder / Editor */}
        {activeTab === 'builder' && (
          <InvoiceEditor
            invoice={currentInvoice}
            setInvoice={setCurrentInvoice}
            shippingCompanies={shippingCompanies}
            customers={customers}
            sellerCompanies={sellerCompanies}
            onSaveInvoice={handleSaveInvoice}
            onPrintPreview={() => setActiveTab('print')}
            onResetInvoice={handleResetInvoice}
            onOpenAiScanner={() => setShowAiScanner(true)}
            onQuickAddShippingCompany={handleQuickAddShipping}
          />
        )}

        {/* TAB 2: Live Print Preview & Customization */}
        {activeTab === 'print' && (
          <div className="space-y-6 max-w-6xl mx-auto pb-16">
            {/* Top Toolbar in Print Tab */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-wrap items-center justify-between gap-4 no-print">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('builder')}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Edit3 className="w-4 h-4 text-slate-600" />
                  الرجوع لتعديل البيانات
                </button>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={handleSaveInvoice}
                  className="px-4 py-2.5 bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-colors"
                >
                  حفظ الفاتورة بالأرشيف
                </button>

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-black shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition-all hover:scale-[1.02]"
                >
                  <Printer className="w-5 h-5" />
                  طباعة الفاتورة الآن (Print) 🖨️
                </button>
              </div>
            </div>

            {/* Split Grid: Customizer Panel on Side + Live Printable Invoice */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Customization Controls (No-Print) */}
              <div className="lg:col-span-5 no-print">
                <InvoiceCustomizer
                  customization={customization}
                  setCustomization={setCustomization}
                  sellerLogo={activeSeller.logoUrl}
                  onUpdateSellerLogo={(url) => {
                    handleSaveSellerCompany({ ...activeSeller, logoUrl: url });
                  }}
                />
              </div>

              {/* The Live Invoice Page (Ready for window.print()) */}
              <div className="lg:col-span-7 print-container">
                <div className="bg-slate-100 p-3 sm:p-6 rounded-3xl border border-slate-200 shadow-inner no-print mb-4 flex items-center justify-between text-xs text-slate-600">
                  <span className="font-bold flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    معاينة حية دقيقة لما سيظهر على الورق عند الطباعة
                  </span>
                  <span className="bg-white px-2.5 py-1 rounded-md border font-bold">
                    المقاس: {customization.paperSize.toUpperCase()}
                  </span>
                </div>

                <PrintableInvoice
                  invoice={currentInvoice}
                  sellerCompany={activeSeller}
                  customization={customization}
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Customers CRM & Sales History */}
        {activeTab === 'customers' && (
          <CustomerManager
            customers={customers}
            invoices={invoices}
            onSaveCustomer={handleSaveCustomer}
            onDeleteCustomer={handleDeleteCustomer}
            onCreateInvoiceForCustomer={handleCreateInvoiceForCustomer}
            onViewInvoice={(inv) => {
              setCurrentInvoice(inv);
              setActiveTab('print');
            }}
          />
        )}

        {/* TAB 4: Shipping Companies Management */}
        {activeTab === 'shipping' && (
          <ShippingCompaniesManager
            shippingCompanies={shippingCompanies}
            onSaveCompany={handleSaveShippingCompany}
            onTogglePin={handleTogglePinShipping}
            onDeleteCompany={handleDeleteShippingCompany}
          />
        )}

        {/* TAB 5: Seller & Brand Profile */}
        {activeTab === 'seller' && (
          <CompanyProfileManager
            sellerCompanies={sellerCompanies}
            onSaveCompany={handleSaveSellerCompany}
            onSetDefaultCompany={handleSetDefaultSellerCompany}
          />
        )}

        {/* TAB 6: Invoices Archive */}
        {activeTab === 'archive' && (
          <InvoiceArchive
            invoices={invoices}
            onSelectInvoice={handleSelectInvoiceFromArchive}
            onDuplicateInvoice={handleDuplicateInvoice}
            onDeleteInvoice={handleDeleteInvoice}
            onStatusChange={handleStatusChange}
          />
        )}
      </main>

      {/* AI Image Extractor Modal (Triggerable anywhere) */}
      {showAiScanner && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto no-print">
          <div className="max-w-3xl w-full my-8">
            <ImageUploader
              onDataExtracted={handleDataExtracted}
              onClose={() => setShowAiScanner(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}
