import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT) || 3000;

// Allow large payloads for high-resolution invoice photos
app.use(express.json({ limit: '35mb' }));
app.use(express.urlencoded({ extended: true, limit: '35mb' }));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
  });
});

// AI Invoice extraction endpoint using Gemini 3.8 Flash (Supports single or multiple images)
app.post('/api/extract-invoice', async (req, res) => {
  try {
    const { image, mimeType, images } = req.body;

    // Collect all input images
    let rawImagesList: Array<{ image: string; mimeType?: string }> = [];
    if (Array.isArray(images) && images.length > 0) {
      rawImagesList = images;
    } else if (image) {
      rawImagesList = [{ image, mimeType }];
    }

    if (rawImagesList.length === 0) {
      return res.status(400).json({ error: 'لم يتم إرسال أي صورة للمعالجة' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({
        error: 'مفتاح Gemini API غير مهيأ في الخادم (GEMINI_API_KEY). يرجى التأكد من ضبط الإعدادات.',
      });
    }

    // Prepare inlineData parts for all uploaded images
    const imageParts = rawImagesList.map((item) => {
      let base64Data = item.image;
      let detectedMime = item.mimeType || 'image/jpeg';

      if (base64Data.includes(',')) {
        const parts = base64Data.split(',');
        const match = parts[0].match(/data:(.*?);base64/);
        if (match && match[1]) {
          detectedMime = match[1];
        }
        base64Data = parts[1];
      }

      return {
        inlineData: {
          mimeType: detectedMime,
          data: base64Data,
        },
      };
    });

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const promptText = `
أنت خبير فائق الدقة في قراءة الفواتير وإيصالات الشحن ومحادثات طلبات الواتساب والمتاجر الإلكترونية المكتوبة باللغة العربية أو الإنجليزية أو العامية المصرية والعربية.
الصور المرفقة (عددها ${imageParts.length}) تتبع نفس الفاتورة أو الطلب (قد تكون صفحات متعددة، أو لقطة شاشة للعنوان ولقطة شاشة أخرى لقائمة المنتجات، أو وجه وظهر إيصال الشحن).
المطلوب استخراج ودمج كافة بيانات الفاتورة من جميع الصور بدقة تامة وبشكل متكامل:
1. اسم العميل (المستلم): استخرجه بدقة من أي صورة يتواجد بها وتجنب وضع ألقاب مفرطة.
2. رقم هاتف العميل (الموبايل): استخرج أرقام الهاتف بشكل صحيح (مثل 010... أو 011... أو +966...). إذا كان هناك رقمين استخرج الرئيسي أو ادمجهما.
3. عنوان العميل: استخرج العنوان الكامل مع اسم المحافظة أو المدينة والحي والشارع والعلامة المميزة.
4. المدينة أو المحافظة: استخرج المحافظة/المدينة كقيمة منفصلة إن ظهرت (مثال: القاهرة، الجيزة، الإسكندرية، المنصورة، الرياض، جدة).
5. المنتجات المطلوبة (items): استخرج واجمع كافة المنتجات من جميع الصور (إذا كانت هناك صور متعددة تحتوي على منتجات مختلفة، اجمعها كلها، وتجنب التكرار لنفس المنتج):
   - name: اسم المنتج بدقة ومواصفاته (المقاس، اللون، النوع).
   - quantity: الكمية كرقم صحيح (افتراضي 1 إذا لم يذكر).
   - price: سعر الوحدة كرقم (إن وجد).
   - total: إجمالي المنتج (الكمية × السعر).
6. اسم شركة الشحن (shippingCompany): إن وُجد في أي صورة اسم شركة شحن أو توصيل (مثل بوسطة Bosta، أرامكس Aramex، سمسا SMSA، ريد بوكس RedBox، Mylerz، مندوب خاص، أو غيرها).
7. سعر الشحن (shippingCost): تكلفة الشحن كرقم إن ذكرت في الصور، أو 0 إذا لم تذكر.
8. رقم الفاتورة أو كود البوليصة (invoiceNumber): إن وجد كود أو رقم طلب.
9. تاريخ الفاتورة أو الطلب (date): بتنسيق YYYY-MM-DD أو كما هو مذكور.
10. ملاحظات (notes): أي ملاحظات تسليم أو مواعيد مفضلة أو تعليمات للمندوب.

إذا كانت الصور غير واضحة في أي تفصيل، خمن الأقرب منطقياً وضع البيانات الفارغة كنصوص فارغة أو قيم صفرية.
    `.trim();

    // Candidate models in fallback order
    const candidateModels = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];
    let responseText: string | undefined = undefined;
    let lastError: any = null;

    for (const modelName of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: [
            ...imageParts,
            {
              text: promptText,
            },
          ],
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                customerName: {
                  type: Type.STRING,
                  description: 'اسم العميل / المستلم',
                },
                customerPhone: {
                  type: Type.STRING,
                  description: 'رقم هاتف العميل أو الجوال',
                },
                customerAddress: {
                  type: Type.STRING,
                  description: 'العنوان التفصيلي للعميل',
                },
                city: {
                  type: Type.STRING,
                  description: 'المحافظة أو المدينة',
                },
                invoiceNumber: {
                  type: Type.STRING,
                  description: 'رقم الفاتورة أو كود الطلب إن وجد',
                },
                date: {
                  type: Type.STRING,
                  description: 'تاريخ الفاتورة أو الشحن',
                },
                shippingCompany: {
                  type: Type.STRING,
                  description: 'اسم شركة الشحن أو التوصيل',
                },
                shippingCost: {
                  type: Type.NUMBER,
                  description: 'تكلفة أو مصاريف الشحن كرقم',
                },
                notes: {
                  type: Type.STRING,
                  description: 'أي ملاحظات إضافية خاصة بالطلب أو التوصيل',
                },
                items: {
                  type: Type.ARRAY,
                  description: 'قائمة الأصناف والمنتجات المطلوبة',
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: {
                        type: Type.STRING,
                        description: 'اسم أو تفاصيل المنتج',
                      },
                      quantity: {
                        type: Type.NUMBER,
                        description: 'الكمية المطلوبة',
                      },
                      price: {
                        type: Type.NUMBER,
                        description: 'سعر القطعة الواحدة',
                      },
                      total: {
                        type: Type.NUMBER,
                        description: 'إجمالي سعر هذا الصنف',
                      },
                    },
                    required: ['name', 'quantity', 'price'],
                  },
                },
              },
              required: ['customerName', 'items'],
            },
          },
        });

        if (response.text) {
          responseText = response.text;
          break;
        }
      } catch (err: any) {
        console.warn(`Attempt with ${modelName} encountered error:`, err?.message || err);
        lastError = err;
        // Brief pause before trying fallback model
        await new Promise((res) => setTimeout(res, 800));
      }
    }

    if (!responseText) {
      const errMsg = lastError?.message || '';
      if (errMsg.includes('503') || errMsg.includes('high demand') || errMsg.includes('UNAVAILABLE')) {
        throw new Error('خوادم الذكاء الاصطناعي تشهد ضغطاً مؤقتاً، يرجى الضغط على زر "إعادة المحاولة" وسيقوم النظام بفحص كافة الصور المرفوعة فوراً.');
      }
      throw new Error(lastError?.message || 'لم نتمكن من استخراج بيانات الفاتورة، يرجى المحاولة مرة أخرى.');
    }

    const parsedData = JSON.parse(responseText);
    return res.json({
      success: true,
      data: parsedData,
    });
  } catch (error: any) {
    console.error('Extraction error:', error);
    let userFriendlyError = error?.message || 'حدث خطأ أثناء معالجة وقراءة الصور';
    if (typeof userFriendlyError === 'string' && userFriendlyError.includes('503')) {
      userFriendlyError = 'خوادم معالجة الصور تشهد ضغطاً مؤقتاً، يرجى الضغط على "إعادة المحاولة" مجدداً.';
    }
    return res.status(500).json({
      success: false,
      error: userFriendlyError,
    });
  }
});

// Server-side Vite dev middleware or static serving
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Smart Invoice Server running at http://0.0.0.0:${port}`);
  });
}

startServer();
